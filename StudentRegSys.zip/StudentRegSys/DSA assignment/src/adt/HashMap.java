/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adt;

public class HashMap<K, V> implements MapInterface<K, V> {
    private static final int DEFAULT_CAPACITY = 16; //initial size of the buckets arraylist
    private static final double LOAD_FACTOR = 0.75; //threshold that triggers resizing of the buckets when entries more than 75%

    private ArrayList<LinkedList<Entry<K, V>>> buckets; //an arraylist where each element is a linkedlist of Entry objects
    private int size;   //total number of entries 

    private static class Entry<K, V> { //each Entry stores one key-value(one/many) pair
        K key;
        ListInterface<V> values;

        Entry(K key, ListInterface<V> values) {
            this.key = key;
            this.values = values;
        }
    }

    public HashMap() {//constructor to create hashmap with default initial capacity 
        this(DEFAULT_CAPACITY);
    }

    public HashMap(int initialCapacity) {   //allow to specify the initial capacity
        buckets = new ArrayList<>(initialCapacity);
        for (int i = 0; i < initialCapacity; i++) {
            buckets.add(new LinkedList<>());
        }
    }

    public void put(K key, V value) {   //adds a new key-value pair to hashMap
        int index = getIndex(key);      //calc the index in the buckets arraylist where the Entry for the provided key should be stored
        LinkedList<Entry<K, V>> bucket = buckets.get(index);    //retrieves the linkedlist at that index

        for (Entry<K, V> entry : bucket) {  //if key alr exists, update the value
            if (entry.key.equals(key)) {
                entry.values.add(value);
                return;
            }
        }
        
        ListInterface<V> values = new ArrayList<>();
        values.add(value);
        bucket.add(new Entry<>(key, values));    //if not exists, create and adds to the bucket
        size++;

        if ((double) size / buckets.size() > LOAD_FACTOR) { //increase the capacity if more than 0.75
            rehash();
        }
    }

    public ListInterface<V> get(K key) {   //return the value associated with the provided key
        int index = getIndex(key);
        LinkedList<Entry<K, V>> bucket = buckets.get(index);

        for (Entry<K, V> entry : bucket) {  //checks if the key exists in the bucket
            if (entry.key.equals(key)) {
                return entry.values;
            }
        }

        return null;
    }

    public boolean containsKey(K key) { //check if the hashMap got the provided key
        int index = getIndex(key);
        LinkedList<Entry<K, V>> bucket = buckets.get(index);

        for (Entry<K, V> entry : bucket) {
            if (entry.key.equals(key)) {
                return true;
            }
        }

        return false;
    }

    public void remove(K key, V value) { //remove the Entry associaated with the provided key
        int index = getIndex(key);
        LinkedList<Entry<K, V>> bucket = buckets.get(index);

        for (Entry<K, V> entry : bucket) {
            if (entry.key.equals(key)) {
                entry.values.remove(value);
                if (entry.values.isEmpty()) {
                    bucket.remove(entry);   //passing an obj to remove 
                    size--;
                }
                return;
            }
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private int getIndex(K key) {   //calculates the index in the buckets ArrayList where the Entry for the provided key should be stored or retrieved from
        return Math.abs(key.hashCode()) % buckets.size();
    }

    private void rehash() {
        ArrayList<LinkedList<Entry<K, V>>> oldBuckets = buckets;
        buckets = new ArrayList<>(oldBuckets.size() * 2);
        for (int i = 0; i < oldBuckets.size() * 2; i++) {
            buckets.add(new LinkedList<>());
        }
        size = 0;   //to reflects the number of entries after re adding the old entries

        for (LinkedList<Entry<K, V>> bucket : oldBuckets) { //iterates over each Entry in each bucket of the old buckets ArrayList, and adds each Entry to the new buckets ArrayList 
            for (Entry<K, V> entry : bucket) {
                for (V value : entry.values) {
                    put(entry.key, value);
                }
            }
        }
    }
}

