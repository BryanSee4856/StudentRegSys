/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package adt;


public interface MapInterface<K, V> {
    void put(K key, V value);
    ListInterface<V> get(K key);
    void remove(K key, V value);
    boolean containsKey(K key);
    int size();
    boolean isEmpty();
}

