package boundary;

import java.util.Scanner;
import control.StudentRegistrationManagement;
import control.TeachingAssignmentManagement;

public class Menu {
    public static void StuRegManagementMenu(Scanner scanner, StudentRegistrationManagement regManager) {
        int choice;
        do {
            System.out.println("\nStudent Registration Management Menu");
            System.out.println("1. Add Student");
            System.out.println("2. Remove Student (Under Development)");
            System.out.println("3. Amend Student Details (Under Development)");
            System.out.println("4. Search Student for Registered Courses (Under Development)");
            System.out.println("5. Add Student to Courses (Under Development)");
            System.out.println("6. Remove Student from Courses (Under Development)");
            System.out.println("7. Calculate Fees for Registered Courses (Under Development)");
            System.out.println("8. Filter Students for Courses (Under Development)");
            System.out.println("9. Generate Summary Reports (Under Development)");
            System.out.println("0. Back");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character left over by nextInt()

            switch (choice) {
                case 1 -> regManager.addStudent(scanner);
                case 2, 3, 4, 5, 6, 7, 8, 9 -> System.out.println("This feature is currently under development.");
                case 0 -> {
                    System.out.println("Returning to the main menu...");
                    return;
                }
                default -> System.out.println("Invalid choice. Please enter a number between 0 and 9.");
            }
        } while (choice != 0);
    }

    public static void TeachingAssignmentManagementMenu(Scanner scanner, TeachingAssignmentManagement tam) {
        int choice;
        do {
            System.out.println("\n--- Teaching Assignment Subsystem Menu ---");
            System.out.println("1. Assign tutor to courses");
            System.out.println("2. Assign tutorial groups to a tutor");
            System.out.println("3. Add tutors to a tutorial group for a course");
            System.out.println("4. Search courses under a tutor");
            System.out.println("5. Search tutors for a course");
            System.out.println("6. List tutors and tutorial groups for a course");
            System.out.println("7. List courses for each tutor");
            System.out.println("8. Filter tutors based on criteria");
            System.out.println("9. Generate summary reports");
            System.out.println("0. Exit");
            System.out.print("Select an option: ");
            
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character left over by nextInt()

            switch (choice) {
                case 1 -> tam.assignTutorToCourse(scanner);
                // ... other cases for each menu option
                case 0 -> {
                    System.out.println("Exiting the Teaching Assignment Subsystem...");
                    return;
                }
                default -> System.out.println("Invalid option. Please try again.");
            }
        } while (choice != 0);
    }
}

    

