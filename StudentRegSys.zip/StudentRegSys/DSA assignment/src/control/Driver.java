package control;

import java.util.Scanner;
import boundary.Menu;
import dao.CourseInitializer;
import dao.TutorInitializer;

public class Driver {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            StudentRegistrationManagement regManager = new StudentRegistrationManagement();
            CourseInitializer courseInit = new CourseInitializer();
            TutorInitializer tutorInit = new TutorInitializer();
            TeachingAssignmentManagement tam = new TeachingAssignmentManagement();

            // Populate the lists
            tam.setCourses(courseInit.getCourseList());
            tam.setTutors(tutorInit.getTutors());
            int choice;
            do {
                System.out.println("Welcome to the Student Management System");
                System.out.println("1. Student Registration Management");
                System.out.println("2. Course Management");
                System.out.println("3. Teaching Assignment Management");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume the newline character left over by nextInt()
                
                switch (choice) {
                    case 1 -> Menu.StuRegManagementMenu(scanner, regManager);
                    case 2 -> System.out.println("Course Management is under development.");
                    case 3 -> Menu.TeachingAssignmentManagementMenu(scanner, tam);
                    case 0 -> System.out.println("Exiting program...");
                    default -> System.out.println("Invalid choice. Please enter a number between 0 and 3.");
                }
            } while (choice != 0);
            // Close the scanner here at the very end
        }
    }
}
