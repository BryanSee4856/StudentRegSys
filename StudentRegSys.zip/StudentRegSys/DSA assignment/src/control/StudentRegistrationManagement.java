package control;

import entity.Student;
import adt.ArrayList;
import java.math.BigDecimal;
import java.util.Scanner;
import adt.ListInterface;

public class StudentRegistrationManagement {
    private ListInterface<Student> students;

    public StudentRegistrationManagement() {
        this.students = new ArrayList<>();
    }

    public void addStudent(Scanner scanner) {
        System.out.println("Enter Student ID: ");
        String id = scanner.nextLine();
        System.out.println("Enter Student Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter Student IC: ");
        String ic = scanner.nextLine();
        System.out.println("Enter Student Email: ");
        String email = scanner.nextLine();

        Student newStudent = new Student(id, name, ic, email);
        if (students.add(newStudent)) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Student already exists.");
        }
    }

    public boolean removeStudent(String studentId) {
        for (int i = 0; i < students.getNumberOfEntries(); i++) {
            if (students.getEntry(i).getStudentId().equals(studentId)) {
                students.remove(i);
                return true;
            }
        }
        return false; // Student not found
    }

    public boolean updateStudentInformation(String studentId, String newName, String newEmail) {
        Student student = findStudentById(studentId);
        if (student != null) {
            student.setName(newName);
            student.setEmail(newEmail);
            return true;
        }
        return false; // Student not found
    }
    
    // Helper method to find a student by ID
    private Student findStudentById(String studentId) {
        for (int i = 0; i < students.getNumberOfEntries(); i++) {
            Student student = students.getEntry(i);
            if (student.getStudentId().equals(studentId)) {
                return student;
            }
        }
        return null;
    }
    
    // 3 methods about course

    public BigDecimal calculateFees(String studentId) {
        // Dummy implementation, actual fee calculation logic would depend on the course details
        return new BigDecimal("1000.00"); // Placeholder value
    }

    public void generateReports() {
        // Dummy implementation, to be expanded with actual report generation logic
        System.out.println("Generating reports...");
        System.out.println("Total Students: " + students.getNumberOfEntries());
    }
}
