/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.Scanner;
import adt.LinkedList; // Your custom LinkedList
import entity.Course;
import entity.Tutor;

public class TeachingAssignmentManagement {
    private LinkedList<Course> courseList;
    private LinkedList<Tutor> tutors; 
    
    public TeachingAssignmentManagement() {
    this.courseList = new LinkedList<>();
    this.tutors = new LinkedList<>();
    }

    public void assignTutorToCourse(Scanner scanner) {
    System.out.print("Enter Tutor ID: ");
    String tutorId = scanner.nextLine().trim();
    System.out.print("Enter Course ID: ");
    String courseId = scanner.nextLine().trim();

    if (tutors.isEmpty() || courseList.isEmpty()) {
        System.out.println("Error: No tutors or courses available. Please initialize data.");
        return;
    }

    Tutor tutor = findTutorById(tutorId);
    Course course = findCourseById(courseId);

    if (tutor == null && course == null) {
        System.out.println("Both tutor and course not found. Please check the IDs and try again.");
    } else if (tutor == null) {
        System.out.println("Tutor not found. Please check the Tutor ID and try again.");
    } else if (course == null) {
        System.out.println("Course not found. Please check the Course ID and try again.");
    } else {
        course.addTutor(tutor);
        System.out.println("Tutor " + tutor.getName() + " has been successfully assigned to course " + course.getCourseName() + ".");
    }
}

    private Tutor findTutorById(String tutorId) {
    for (Tutor tutor : this.tutors) { // Assuming 'tutors' is your LinkedList<Tutor>
        if (tutor.getId().trim().equalsIgnoreCase(tutorId.trim())) {
            return tutor;
        }
    }
    return null; // Tutor not found
    }
    
    private Course findCourseById(String courseId) {
    for (Course course : this.courseList) { // Assuming 'courses' is your LinkedList<Course>
        if (course.getCourseID().trim().equalsIgnoreCase(courseId.trim())) {
            return course;
        }
    }
    return null; // Course not found
    }

    public void setCourses(LinkedList<Course> courses) {
        this.courseList = courses;
    }

    public void setTutors(LinkedList<Tutor> tutors) {
        this.tutors = tutors;
    }
}




