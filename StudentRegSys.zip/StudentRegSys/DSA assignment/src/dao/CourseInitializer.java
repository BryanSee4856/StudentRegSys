package dao;
import adt.*;
import entity.*;

public class CourseInitializer {
    private HashMap<String, Course> courses;
    private LinkedList<Course> courseList;
    private ProgrammeInitializer programmeInitializer;
     
    public CourseInitializer() {
        this.courses = new HashMap<>();
        this.courseList = new LinkedList<>();
        this.programmeInitializer = new ProgrammeInitializer();
        initializeCourses();
    }
    
    private void initializeCourses(){
        Course c1 = new Course("BACS6683", "Intorduction to Networking", 777.0, 16, Course.courseType.MAIN);
        Course c2 = new Course("BAMS1044", "Software Engineering", 700.0, 14, Course.courseType.MAIN);
        Course c3 = new Course("BAIT1102", "Web Development", 650.0, 16, Course.courseType.MAIN);
        Course c4 = new Course("AACS1543", "Introduction to Entrepreneurship", 600.0, 15, Course.courseType.ELECTIVE);
   
        // Add courses to both HashMap and LinkedList
        addToBoth(c1);
        addToBoth(c2);
        addToBoth(c3);
        addToBoth(c4);
        
        // Associate programmes with courses
        programmeWithCourse(c1, programmeInitializer.getProgrammeById("RIS")); // Assuming DCS is a programme ID
        programmeWithCourse(c2, programmeInitializer.getProgrammeById("RSW")); // Assuming RSW is a programme ID
        programmeWithCourse(c3, programmeInitializer.getProgrammeById("DCS"));
        
    }
        private void addToBoth(Course course) {
        if (course != null) {
            courses.put(course.getCourseID(), course);
            courseList.add(course);
        }
    }
    
    private void programmeWithCourse(Course course, Programme programme) {
        if (course != null && programme != null) {
            course.getProgrammes().put(programme.getProgrammeID(), programme);
            programme.getCourses().put(course.getCourseID(), course);
        }
    }
    
    public HashMap<String, Course> getCourses() {
        return courses;
    }
    
    public LinkedList<Course> getCourseList() {
        return courseList;
    }
        
    public Course getCourseById(String courseID) {
        return (Course) courses.get(courseID);
    }
}
