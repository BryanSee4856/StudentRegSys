/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import adt.*;
import entity.*;

public class FacultyInitializer {
    private HashMap<String, Faculty> faculties;
    private CourseInitializer courseInitializer;
    
    public FacultyInitializer() {
        this.faculties = new HashMap<>();
        this.courseInitializer = new CourseInitializer();
        initializeFaculties();
    }
    
    private void initializeFaculties() {
        // Initialize faculties here
        Faculty f1 = new Faculty("FOCS", "Faculty of Computing and Information Technology");
        Faculty f2 = new Faculty("FAFB", "Faculty of Accountancy Finance and Business");
        
        // Add faculties to the HashMap
        faculties.put(f1.getFacultyID(), f1);
        faculties.put(f2.getFacultyID(), f2);
        
        // Associate courses with faculties
        // Modify this part according to your use case and data structure
        coursesWithFaculty(f1, "BACS6683"); 
        coursesWithFaculty(f1, "BAMS1044");
        coursesWithFaculty(f2, "BAIT1102");
        coursesWithFaculty(f2, "AACS1543");
    }
    
    private void coursesWithFaculty(Faculty faculty, String courseID) {
        Course course = courseInitializer.getCourseById(courseID);
        if (faculty != null && course != null) {
            faculty.getCourses().put(courseID, course);
        }
    }

    public HashMap<String, Faculty> getFaculties() {
        return faculties;
    }
}
