/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import adt.*;
import entity.*;

public class ProgrammeInitializer {
    private HashMap<String, Programme> programmes;

    public ProgrammeInitializer() {
        this.programmes = new HashMap<>();
        initializeProgrammes();
    }
    
    private void initializeProgrammes() {
        // Initialize programmes here
        Programme p1 = new Programme("DCS", "Computer Science");
        Programme p2 = new Programme("RSW", "Software Engineering");
        Programme p3 = new Programme("RIS", "Information Security");
        Programme p4 = new Programme("RDS", "Data Science");
        
        // Add programmes to the HashMap
        programmes.put(p1.getProgrammeID(), p1);
        programmes.put(p2.getProgrammeID(), p2);
        programmes.put(p3.getProgrammeID(), p3);
        
    }
    
    public HashMap<String, Programme> getProgrammes() {
        return programmes;
    }
    
    public Programme getProgrammeById(String programmeID) {
    try {
        return (Programme) programmes.get(programmeID);
    } catch (ClassCastException e) {
        // Log the error and/or inform the user
        return null;
        }
    }
}
