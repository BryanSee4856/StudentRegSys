/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import adt.*;
import entity.*;

public class SemesterInitializer {
    private HashMap<String, Semester> semesters;
    private CourseInitializer courseInitializer;
    
    public SemesterInitializer() {
        this.semesters = new HashMap<>();
        this.courseInitializer = new CourseInitializer();
        initializeSemester();
    }
    
    private void initializeSemester() {
        Semester semester = new Semester("S001", "Spring 2024"); // Adjust semester ID and name as needed

        // Initialize and associate predefined courses with the semester
        // Example:
        Course c1 = courseInitializer.getCourseById("BACS6683"); 
        Course c2 = courseInitializer.getCourseById("BAMS1044");
        Course c3 = courseInitializer.getCourseById("BAIT1102");
        Course c4 = courseInitializer.getCourseById("AACS1543");

        // Add courses to the semester's HashMap
        if (c1 != null) {
            semester.getCoursesOffered().put(c1.getCourseID(), c1);
        }
        if (c2 != null) {
            semester.getCoursesOffered().put(c2.getCourseID(), c2);
        }
        if (c3 != null) {
            semester.getCoursesOffered().put(c3.getCourseID(), c3);
        }
        if (c4 != null) {
            semester.getCoursesOffered().put(c4.getCourseID(), c4);
        }

        // Add the semester to the HashMap
        semesters.put(semester.getSemesterID(), semester);
    }

    public HashMap<String, Semester> getSemesters() {
        return semesters;
    }
}
