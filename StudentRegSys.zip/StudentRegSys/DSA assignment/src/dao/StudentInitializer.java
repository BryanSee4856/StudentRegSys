package dao;

import entity.*;
import adt.*;

/**
 * Initializes and manages a static array of Student objects.
 * Provides methods to access and populate these students into a ListInterface for broader application use.
 */
public class StudentInitializer {
    private static final Student[] students = {
        new Student("21WMR14601", "Ana", "040512-14-1461", "ana@university.edu"),
        new Student("21WMR14602", "Bob", "040512-14-1462", "bob@university.edu"),
        new Student("21WMR14603", "Cara", "040512-14-1463", "cara@university.edu"),
        new Student("21WMR14604", "Dave", "040512-14-1464", "dave@university.edu"),
        new Student("21WMR14605", "Eve", "040512-14-1465", "eve@university.edu"),
        new Student("21WMR14606", "Finn", "040512-15-1466", "finn@university.edu"),
        new Student("21WMR14607", "Gina", "040512-15-1467", "gina@university.edu"),
        new Student("21WMR14608", "Hugh", "040512-15-1468", "hugh@university.edu"),
        new Student("21WMR14609", "Isla", "040512-15-1469", "isla@university.edu"),
        new Student("21WMR14610", "Jack", "040512-15-1470", "jack@university.edu"),
        new Student("21WMR14611", "Kara", "040512-16-1471", "kara@university.edu"),
        new Student("21WMR14612", "Leo", "040512-16-1472", "leo@university.edu"),
        new Student("21WMR14613", "Mia", "040512-16-1473", "mia@university.edu"),
        new Student("21WMR14614", "Noah", "040512-16-1474", "noah@university.edu"),
        new Student("21WMR14615", "Olive", "040512-16-1475", "olive@university.edu"),
        new Student("21WMR14616", "Pete", "040512-17-1476", "pete@university.edu"),
        new Student("21WMR14617", "Quinn", "040512-17-1477", "quinn@university.edu"),
        new Student("21WMR14618", "Rita", "040512-17-1478", "rita@university.edu"),
        new Student("21WMR14619", "Sam", "040512-17-1479", "sam@university.edu"),
        new Student("21WMR14620", "Tina", "040512-17-1480", "tina@university.edu")
    };

    /**
     * Populates a provided ListInterface with students from a pre-defined array.
     * @param studentList the list interface to populate with student objects.
     */
    public static void populateStudents(ListInterface<Student> studentList) {
        for (Student student : students) {
            studentList.add(student);
        }
    }

    /**
     * Retrieves a student by index from the static student array.
     * @param index the index of the student to retrieve.
     * @return the Student object at the specified index.
     * @throws IndexOutOfBoundsException if the index is out of range (index < 0 || index >= getStudentLength()).
     */
    public static Student getStudent(int index) {
        if (index < 0 || index >= students.length) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for the student array.");
        }
        return students[index];
    }

    /**
     * Returns the total number of students in the static array.
     * @return the number of students.
     */
    public static int getStudentLength() {
        return students.length;
    }
}
