/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import adt.LinkedList;
import entity.Tutor;

public class TutorInitializer {
    private LinkedList<Tutor> tutors;

    public TutorInitializer() {
        tutors = new LinkedList<>();
        initializeTutors();
    }

    private void initializeTutors() {
    // Assuming you have a constructor in Tutor like Tutor(String id, String name)
    tutors.add(new Tutor("John Doe", "T001"));
    tutors.add(new Tutor("Jane Smith", "T002"));
    tutors.add(new Tutor("Emily Johnson", "T003"));
    tutors.add(new Tutor("Michael Brown", "T004"));
    tutors.add(new Tutor("Jessica Garcia", "T005"));
    tutors.add(new Tutor("William Davis", "T006"));
    tutors.add(new Tutor("Linda Wilson", "T007"));
    tutors.add(new Tutor("Robert Miller", "T008"));
    tutors.add(new Tutor("Sarah Moore", "T009"));
    tutors.add(new Tutor("James Taylor", "T010"));
    }
    
        public LinkedList<Tutor> getTutors() {
        return tutors;
    }
}

