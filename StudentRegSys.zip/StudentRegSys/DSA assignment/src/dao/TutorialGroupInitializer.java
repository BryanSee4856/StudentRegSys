/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import entity.Tutor;
import entity.TutorialGroup;
import java.util.LinkedList;

public class TutorialGroupInitializer {
    
    public static LinkedList<TutorialGroup> initializeTutorialGroups() {
        // Create a LinkedList to hold all tutorial groups
        LinkedList<TutorialGroup> tutorialGroups = new LinkedList<>();

        // Create Tutors
        Tutor tutor1 = new Tutor("John Doe", "T001");
        Tutor tutor2 = new Tutor("Jane Smith", "T002");
        Tutor tutor3 = new Tutor("Emily Johnson", "T003");
        Tutor tutor4 = new Tutor("Michael Brown", "T004");
        Tutor tutor5 = new Tutor("Jessica Garcia", "T005");
        Tutor tutor6 = new Tutor("William Davis", "T006");
        Tutor tutor7 = new Tutor("Linda Wilson", "T007");
        Tutor tutor8 = new Tutor("Robert Miller", "T008");
        Tutor tutor9 = new Tutor("Sarah Moore", "T009");
        Tutor tutor10 = new Tutor("James Taylor", "T010");


        // Create Tutorial Groups and assign Tutors
        TutorialGroup group1 = new TutorialGroup("G101");
        group1.addTutor(tutor1);
        group1.addTutor(tutor2);
        
        TutorialGroup group2 = new TutorialGroup("G102");
        group2.addTutor(tutor3);
        group2.addTutor(tutor4);
        
        TutorialGroup group3 = new TutorialGroup("G103");
        group3.addTutor(tutor5);
        group3.addTutor(tutor6);
        
        TutorialGroup group4 = new TutorialGroup("G104");
        group4.addTutor(tutor7);
        group4.addTutor(tutor8);
        
        TutorialGroup group5 = new TutorialGroup("G105");
        group5.addTutor(tutor9);
        group5.addTutor(tutor10);


        // Add Tutorial Groups to the list
        tutorialGroups.add(group1);
        tutorialGroups.add(group2);
        tutorialGroups.add(group3);
        tutorialGroups.add(group4);
        tutorialGroups.add(group5);

        return tutorialGroups;
    }
}

