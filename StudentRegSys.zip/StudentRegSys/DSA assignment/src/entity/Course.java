/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
import adt.*;

public class Course {
    private String courseID;
    private String courseName;
    private double fee;
    private int creditHours;
    private courseType type;
    private HashMap<String, Programme> programmes;
    private LinkedList<Tutor> tutors;
    
    public Course(){
    
    }
    
    public Course(String courseID, String courseName, double fee, int creditHours, courseType type){
        this.courseID = courseID;
        this.courseName = courseName;
        this.fee = fee;
        this.creditHours = creditHours;
        this.type = type;
        this.programmes = new HashMap<>();
        this.tutors = new LinkedList<>();      
    }
    
    public enum courseType {
        MAIN, ELECTIVE
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public courseType getType() {
        return type;
    }

    public void setType(courseType type) {
        this.type = type;
    }

    public HashMap<String, Programme> getProgrammes() {
        return programmes;
    }

    public void setProgrammes(HashMap<String, Programme> programmes) {
        this.programmes = programmes;
    }
    
    public void addTutor(Tutor tutor) {
        if (!this.tutors.contains(tutor)) {
            this.tutors.add(tutor);
        }
    }
    
    public LinkedList<Tutor> getTutors() {
        return tutors;
    }
}
