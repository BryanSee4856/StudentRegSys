/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
import adt.*;

public class Semester {
    private String semesterID;
    private String semesterName;
    private HashMap<String, Course> coursesOffered;
    
    public Semester(String semesterID, String semesterName) {
        this.semesterID = semesterID;
        this.semesterName = semesterName;
        this.coursesOffered = new HashMap<>();
    }

    public String getSemesterID() {
        return semesterID;
    }

    public void setSemesterID(String semesterID) {
        this.semesterID = semesterID;
    }

    public String getSemesterName() {
        return semesterName;
    }

    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }

    public HashMap<String, Course> getCoursesOffered() {
        return coursesOffered;
    }

    public void setCoursesOffered(HashMap<String, Course> coursesOffered) {
        this.coursesOffered = coursesOffered;
    }
    
    
}
