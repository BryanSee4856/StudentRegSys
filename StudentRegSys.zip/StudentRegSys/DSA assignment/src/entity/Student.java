package entity;

import adt.*;

/**
 * Represents a student with a unique ID, name, identification number, group ID, and chosen email.
 * This class is designed to ensure that each student's identity is robustly validated upon creation.
 */
public class Student implements Comparable<Student> {
    private final String studentId;
    private String name;
    private String ic;
    private String groupId;
    private String email;

    /**
     * Constructs a Student with default group ID.
     */
    public Student() {
        this.studentId = "defaultID"; // Provide a default ID or throw an exception
        this.name = "defaultName";
        this.ic = "defaultIC";
        this.email = "default@example.com";
        this.groupId = "none";
    }

    /**
     * Constructs a Student with specified details.
     * @param studentId Unique identifier for the student, must not be null or empty.
     * @param name Student's name, must not be null or empty.
     * @param ic Student's IC number, must not be null or empty.
     * @param email Student's email, must be valid according to standard email formats.
     * @throws IllegalArgumentException if any arguments are invalid.
     */
    public Student(String studentId, String name, String ic, String email) {
        if (studentId == null || studentId.isEmpty()) throw new IllegalArgumentException("Student ID cannot be null or empty.");
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Name cannot be null or empty.");
        if (ic == null || ic.isEmpty()) throw new IllegalArgumentException("IC cannot be null or empty.");
        if (email == null || !email.contains("@") || !email.contains(".")) throw new IllegalArgumentException("Invalid email format.");
        
        this.studentId = studentId;
        this.name = name;
        this.ic = ic;
        this.email = email;
        this.groupId = "none";  // Default value if not specified
    }

    // Getters
    public String getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getIc() { return ic; }
    public String getEmail() { return email; }
    public String getGroupId() { return groupId; }

    // Setters with validation
    public void setName(String name) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Name cannot be null or empty.");
        this.name = name;
    }

    public void setIc(String ic) {
        if (ic == null || ic.isEmpty()) throw new IllegalArgumentException("IC cannot be null or empty.");
        this.ic = ic;
    }

    public void setEmail(String email) {
    if (email == null || !email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}")) {
        throw new IllegalArgumentException("Invalid email format.");
    }
    this.email = email;
}

    public void setGroupId(String groupId) {
        if (groupId == null || groupId.isEmpty()) throw new IllegalArgumentException("Group ID cannot be null or empty.");
        this.groupId = groupId;
    }

    @Override
    public int compareTo(Student other) {
        return this.studentId.compareTo(other.studentId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return studentId.equals(student.studentId);
    }

    @Override
    public int hashCode() {
        return studentId.hashCode();
    }

    @Override
    public String toString() {
        return String.format("Student{studentId='%s', name='%s', ic='%s', groupId='%s', email='%s'}",
                             studentId, name, ic, groupId, email);
    }
}
