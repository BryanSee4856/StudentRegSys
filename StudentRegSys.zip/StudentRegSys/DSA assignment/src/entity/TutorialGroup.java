/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import adt.LinkedList;

/**
 *
 * @author User
 */
public class TutorialGroup {
    private String groupId;
    private LinkedList<Tutor> tutors; // LinkedList to hold tutors in this group

    public TutorialGroup(String groupId) {
        this.groupId = groupId;
        this.tutors = new LinkedList<>();
    }

    // Method to add a tutor to the tutorial group
    public void addTutor(Tutor tutor) {
        tutors.add(tutor);
    }

    // Method to remove a tutor from the tutorial group
    public boolean removeTutor(Tutor tutor) {
        return tutors.remove(tutor);
    }

    // Getters and Setters
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public LinkedList<Tutor> getTutors() {
        return tutors;
    }
}
