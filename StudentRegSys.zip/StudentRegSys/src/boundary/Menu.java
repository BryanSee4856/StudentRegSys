package boundary;

import java.util.Scanner;
import control.StudentRegistrationManagement;
import control.CourseManagement;
import control.TeachingAssignmentManagement;
public class Menu {
    private static final String BORDER = new String(new char[60]).replace('\0', '*');
    private static final String MENU_TITLE_PADDING = new String(new char[5]).replace('\0', ' ');

    public static void printMenuHeader(String title) {
        System.out.println(BORDER);
        System.out.println(MENU_TITLE_PADDING + title);
        System.out.println(BORDER);
    }

    public static void printMenuItem(String item) {
        System.out.println(" * " + item);
    }

    public static void printMenuFooter() {
        System.out.println(BORDER);
    }
    public static void StuRegManagementMenu(Scanner scanner, StudentRegistrationManagement regManager) {
        int choice;
        do {
            // Print the menu header
            System.out.println("\n\n\n");
            System.out.println("============================================================================");
            printMenuHeader("Student Registration Management Menu");
            System.out.println("============================================================================");

            // Print menu items
            printMenuItem("1. Add Student");
            printMenuItem("2. Remove Student");
            printMenuItem("3. Amend Student Details");
            printMenuItem("4. Add Student to Courses");
            printMenuItem("5. Remove Student from Courses");
            printMenuItem("6. Search Student for Registered Courses");
            printMenuItem("7. Filter Students for Courses");
            printMenuItem("8. Calculate Fees for Registered Courses");
            printMenuItem("9. Generate Summary Reports (Under Development)");
            printMenuItem("0. Return to main menu");

            // Print the menu footer
            printMenuFooter();

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character left over by nextInt()

            switch (choice) {
                case 1 -> regManager.addStudent();
                case 2 -> {
                    System.out.println("\n");
                    regManager.listStudents();  // Show the list before removal
                    boolean isRemoved = regManager.removeStudent();  // Process the removal
                    if (isRemoved) {
                        System.out.println("Updated Student List: ");
                        regManager.listStudents();  // Show the updated list only if a student was removed
                    }
                }
                case 3 -> regManager.amendStudent();
                case 4 -> regManager.addStudentCourse();
                case 5 -> regManager.removeStudentCourse();
                case 6 -> regManager.studentRegisteredCourse();
                case 7 -> regManager.FiltersStudents();
                case 8 -> regManager.CalculateFee();
                case 9 -> regManager.StudentReport();
                case 0 -> {
                    System.out.println("Returning to the main menu...");
                    return;  // Ensure that return here exits immediately, skipping any further actions
                }
                default -> System.out.println("Invalid choice. Please enter a number between 0 and 9.");
            }
        } while (choice != 0);
    }
    
    //CourseManagementMenu(){}
    public static void CourseManagementMenu(Scanner scanner, CourseManagement courseManager) {
        int choice;
        do {
            printMenuHeader("Course Management Menu");
            printMenuItem("1. Add a programme to course");
            printMenuItem("2. Remove a programme from a course");
            printMenuItem("3. Add a new course to programme");
            printMenuItem("4. Remove a course from a programme");
            printMenuItem("5. Search courses offered in this semester");
            printMenuItem("6. Amend course details for a programme");
            printMenuItem("7. List courses taken by different faculties");
            printMenuItem("8. List all courses for a programme");
            printMenuItem("9. Generate Course Summary Report");
            printMenuItem("10.Generate Course Financial Report");
            printMenuItem("0. Return to main menu");
            printMenuFooter();
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character left over by nextInt()

            switch (choice) {
                case 1 -> courseManager.addProgrammeToCourse();
                case 2 -> courseManager.removeProgrammeFromCourse();
                case 3 -> courseManager.addNewCourseToProgramme();
                case 4 -> courseManager.removeCourseFromProgramme();
                case 5 -> courseManager.displayCoursesForSemester();
                case 6 -> courseManager.amendCourseDetails();
                case 7 -> courseManager.displayCoursesByFaculty();
                case 8 -> courseManager.displayCoursesForProgramme();
                case 9 -> courseManager.generateCourseSummaryReport();
                case 10 -> courseManager.generateCourseFinancialReport();
                case 0 -> {
                    System.out.println("Returning to the main menu...");
                    return;
                }
                default -> System.out.println("Invalid choice. Please enter a number between 0 and 9.");
            }
        } while (choice != 0);
    }
    
    // public static void TutorialManagementMenu(){}
    public static void TeachingAssignmentManagementMenu(Scanner scanner, TeachingAssignmentManagement tam) {
        int choice;
        do {
            printMenuHeader("Teaching Assignment Subsystem Menu");
            printMenuItem("1. Assign tutor to courses");
            printMenuItem("2. Assign tutorial groups to a tutor");
            printMenuItem("3. Add tutors to a tutorial group for a course");
            printMenuItem("4. Search courses under a tutor");
            printMenuItem("5. Search tutors for a course");
            printMenuItem("6. List tutors and tutorial groups for a course");
            printMenuItem("7. List courses for each tutor");
            printMenuItem("8. Filter tutors based on Role Type");
            printMenuItem("9. Generate summary reports");
            printMenuItem("0. Return to main menu");
            printMenuFooter();
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character left over by nextInt()

            switch (choice) {
                case 1 -> tam.assignTutorToCourse(scanner);
                case 2 -> tam.assignTutorialGroupToTutor();
                case 3 -> tam.assignTutorToTutorialGroupInCourse();
                case 4 -> tam.performCourseSearch();
                case 5 -> tam.displayRolesByCourseAndType(); 
                case 6 -> tam.listTutorsAndTutorialGroupsForCourse();
                case 7 -> tam.listCoursesForEachTutor();
                case 8 -> tam.filterTutorsByUserInput();
                case 9 -> tam.generateSummaryReport();
                case 0 -> {
                    System.out.println("Exiting the Teaching Assignment Subsystem...");
                    return;
                }
                default -> System.out.println("Invalid option. Please try again.");
            }
        } while (choice != 0);
    }
}    
