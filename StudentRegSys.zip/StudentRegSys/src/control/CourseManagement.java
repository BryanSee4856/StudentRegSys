package control;
import java.util.Scanner;
import adt.*;
import dao.*;
import entity.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import static boundary.Menu.printMenuHeader;
import static boundary.Menu.printMenuFooter;

public class CourseManagement {
    private HashMap<String, Course> courses;
    private HashMap<String, Programme> programmes;
    private Scanner scanner;
    private SemesterInitializer semesterInitializer;
    private HashMap<String, Faculty> faculties;
    private CourseInitializer courseInitializer;  // Needed to pass to getInstance()
    private StudentRegistrationManagement studentRegistrationManagement;
    
    public CourseManagement(HashMap<String, Course> courses, HashMap<String, Programme> programmes, HashMap<String, Faculty> faculties, Scanner scanner, SemesterInitializer semesterInitializer, CourseInitializer courseInitializer) {
        this.courses = courses;
        this.programmes = programmes;
        this.faculties = faculties;
        this.scanner = scanner;
        this.semesterInitializer = semesterInitializer;
        this.courseInitializer = courseInitializer;
    }
    
    public void setStudentRegistrationManagement(StudentRegistrationManagement studentRegistrationManagement) {
        this.studentRegistrationManagement = studentRegistrationManagement;
    }
    
    public void displayProgrammes() {
        System.out.println();
        printMenuHeader("List of Programmes:");
        for (Programme programme : programmes.values()) {
            System.out.println(programme.getProgrammeID() + " - " + programme.getProgrammeName());
        }
        printMenuFooter();
    }
     
    public void displayCourses() {
        System.out.println();
        printMenuHeader("List of Courses");
        for (Course course : courses.values()) {
            System.out.println(course.getCourseID() + " - " + course.getCourseName());
        }
        printMenuFooter();
    }
    
    public Course getCourse(String courseId) {
        return courses.get(courseId);
    }

    public void displayCoursesWithProgrammes() {
        System.out.println();
        printMenuHeader("List of Courses with Associated Programmes:");
        for (Course course : courses.values()) {
            System.out.println("Course ID: " + course.getCourseID() + " - Course Name: " + course.getCourseName());
            System.out.println("Associated Programmes:");
            HashMap<String, Programme> associatedProgrammes  = course.getProgrammes();
            for (Programme programme : associatedProgrammes .values()) {
                System.out.println("\t" + programme.getProgrammeID() + " - " + programme.getProgrammeName());
            }
            System.out.println(); // Add a new line for better readability
        }
    }
   
    public void addProgrammeToCourse() {
        displayProgrammes();
        String programmeId;
        Programme programme = null;
        
        while(true){
            System.out.print("Enter the programme ID to add to the course: ");
            programmeId = scanner.nextLine();

            programme = programmes.get(programmeId);
            if (programme != null) {
                break; // Exit the loop if a valid programme ID is entered
            }else{
                System.out.println("Programme not found. Please enter a valid programme ID.");
            }
        }

        displayCourses();
        String courseId;
        Course course = null;
        
        while(true){
            System.out.print("Enter the course ID for the chosen programme to add: ");
            courseId = scanner.nextLine();

            course = courses.get(courseId);
            if (course != null) {
                // Check if the programme has already been added to the course
                HashMap<String, Programme> programmeMap = course.getProgrammes();
                if (programmeMap.containsKey(programmeId)) {
                    System.out.println("This programme is already added to the course.");
                }else{
                    break;
                }
            }else{
                System.out.println("Course not found. Please enter a valid course ID.");
            }
        }

        // Add programme to course
        HashMap<String, Programme> programmeMap = course.getProgrammes();
        programmeMap.put(programmeId, programme);
         // Ensure to also add the course to the programme's list of courses
        HashMap<String, Course> courseMap = programme.getCourses();
        if (courseMap == null) {
            courseMap = new HashMap<>();
            programme.setCourses(courseMap);
        }
        courseMap.put(courseId, course);
        
        System.out.println("\nProgramme added to the course successfully.");
        promptEnterToContinue(scanner);
        displayCoursesWithProgrammes();
    }
    
    public void removeProgrammeFromCourse() {
    displayCourses();
    String courseId;
    Course course = null;
    Programme programme = null;

    while (true) {
        System.out.print("Enter the course ID to remove the programme from: ");
        courseId = scanner.nextLine();

        course = courses.get(courseId);
        if (course != null) {
            break; // Exit the loop if a valid course ID is entered
        } else {
            System.out.println("Course not found. Please enter a valid course ID.");
        }
    }

    HashMap<String, Programme> programmeMap = course.getProgrammes();
            
    if (programmeMap.isEmpty()) {
        System.out.println("No programmes associated with this course.");
        return;
    }

    System.out.println("Programmes associated with this course:");
    for (Programme p : programmeMap.values()) {
        System.out.println(p.getProgrammeID() + " - " + p.getProgrammeName());
    }

    String programmeId;

    while (true) {
        System.out.print("Enter the programme ID to remove from the course: ");
        programmeId = scanner.nextLine();

        if (programmeMap.containsKey(programmeId)) {
            programme = programmes.get(programmeId);
            programmeMap.remove(programmeId);
            HashMap<String, Course> courseMap = programme.getCourses();
            courseMap.remove(courseId);
            System.out.println("\nProgramme removed from the course successfully.");
            promptEnterToContinue(scanner);
            break; // Exit the loop if a valid programme ID is entered
        } else {
            System.out.println("Programme not found. Please enter a valid programme ID.");
        }
    }
    
    displayCoursesWithProgrammes();
    }
    
    public void addNewCourseToProgramme() {
        displayProgrammes();
        String programmeId;
        Programme programme = null;
        
        while(true){
            System.out.print("Enter the programme ID to add a new course to: ");
            programmeId = scanner.nextLine();

            programme = programmes.get(programmeId);
            if (programme != null) {
                break; // Exit the loop if a valid programme ID is entered
            }else{
                System.out.println("Programme not found. Please enter a valid programme ID.");
            }
        }

        System.out.print("Enter the new course ID: ");
        String courseId = validateCourseId();
        System.out.print("Enter the new course name: ");
        String courseName = scanner.nextLine();
        double fee = promptForDouble("Enter the new course fee: ");
        int creditHours = promptForInt("Enter the new course credit hours: ");
        scanner.nextLine();
        System.out.println("Enter the new course type (MAIN or ELECTIVE): ");
        Course.courseType type = validateCourseType();

        // Create the new course and add it to the HashMap
        Course newCourse = new Course(courseId, courseName, fee, creditHours, type);
        courses.put(courseId, newCourse);
        // Add the new course to the programme
        programme.getCourses().put(newCourse.getCourseID(), newCourse);
        newCourse.getProgrammes().put(programme.getProgrammeID(), programme); 
        System.out.println("\nNew course added to the programme successfully.");
        promptEnterToContinue(scanner);
        
        // Associate the course with the correct faculty based on programme
        FacultyInitializer.getInstance(courseInitializer).associateCourseWithFaculty(programmeId, newCourse);
        
        displayCoursesWithProgrammes();
        // Add course to current semester
        semesterInitializer.addCourseToCurrentSemester(newCourse.getCourseID());
    }
    
    public void removeCourseFromProgramme() {
    displayProgrammes();
    String programmeId;
    Programme programme = null;
    while(true){
        System.out.print("Enter the programme ID to remove the course: ");
        programmeId = scanner.nextLine().trim().toUpperCase();

        programme = programmes.get(programmeId);
        if (programme != null) {
            break; // Exit the loop if a valid programme ID is entered
        }else{
            System.out.println("Programme not found. Please enter a valid programme ID.");
        }
    }
    
    HashMap<String, Course> courseMap = programme.getCourses();
    
    if (courseMap.isEmpty()) {
        System.out.println("No courses associated with this programme.");
        return;
    }
    
    // Display courses associated with the programme
    System.out.println("Courses in the selected programme:");
    for (Course course : programme.getCourses().values()) {
        System.out.println(course.getCourseID() + " - " + course.getCourseName());
    }

    // Prompt for the course ID to remove
    String courseId;
    Course course = null;
    while(true){
        System.out.print("Enter the course ID to remove from the programme: ");
        courseId = scanner.nextLine().trim().toUpperCase();
        course = courses.get(courseId);
        if(course != null){
            break;
        }else{
            System.out.println("Course not found. Please enter a valid course ID.");
        }
    }
    if (course != null && programme.getCourses().containsKey(courseId)) {
        programme.getCourses().remove(courseId);
        course.getProgrammes().remove(programme.getProgrammeID());
        System.out.println("\nCourse removed from the programme successfully.");
        promptEnterToContinue(scanner);
        } else {
            System.out.println("Invalid course ID or course not found in the selected programme.");
        }
        displayCoursesWithProgrammes(); //display the updated list
    }
    
    public void displayCoursesForSemester() {
    String defaultSemesterId = "Year1S1";
    Semester semester = semesterInitializer.getSemesterById(defaultSemesterId);
    if (semester != null) {
        System.out.println("Courses offered in " + semester.getSemesterID() + ":");
        for (Course course : semester.getCoursesOffered().values()) {
            System.out.println(course.getCourseID() + " - " + course.getCourseName());
        }
    } else {
        System.out.println("No such semester found.");
        }
    }
    
    public void amendCourseDetails(){
    displayProgrammes();
    String programmeId;
    Programme programme = null;
    while(true){
        System.out.print("Enter the programme ID to amend the course: ");
        programmeId = scanner.nextLine().trim().toUpperCase();

        programme = programmes.get(programmeId);
        if (programme != null) {
            break;
        }else{
            System.out.println("Programme not found. Please enter a valid programme ID.");
            }
        }
    amendCourseDetails(programme);   
    }
    
    private void amendCourseDetails(Programme programme) {
        HashMap<String, Course> courseMap = programme.getCourses();
    
        if (courseMap.isEmpty()) {
            System.out.println("No courses associated with this programme.");
            return;
        }
        
        System.out.println("Courses in " + programme.getProgrammeName() + ":");
        for (Course course : programme.getCourses().values()) {
            System.out.println(course.getCourseID() + " - " + course.getCourseName());
        }
        String courseId;
        Course course = null;
            while (true) {
                System.out.print("Enter the course ID to amend details: ");
                courseId = scanner.nextLine().trim().toUpperCase();

                course = programme.getCourses().get(courseId);
                if (course != null) {
                    break; 
                } else {
                    System.out.println("Course not found within the selected programme. Please enter a valid course ID.");
                }
            }
        updateCourseDetails(course);
    }
    
    private void updateCourseDetails(Course course) {
    System.out.println("Amending details for " + course.getCourseName());
    System.out.println("1. Name");
    System.out.println("2. Fee");
    System.out.println("3. Credit Hours");
    System.out.println("4. Course Type (MAIN or ELECTIVE):");
    System.out.print("Select the detail to amend: ");
    int choice = scanner.nextInt();
    scanner.nextLine();

    switch (choice) {
        case 1:
            System.out.print("Enter new name: ");
            course.setCourseName(scanner.nextLine());
            break;
        case 2:
            course.setFee(promptForDouble("Enter new fee: "));
            break;
        case 3:
            course.setCreditHours(promptForInt("Enter new credit hours: "));
            break;
        case 4:
            course.setType(validateCourseType());
            break;
        default:
            System.out.println("Invalid choice. Please select a valid option.");
            return;
    }
    System.out.println("\nCourse details updated successfully.");
    displayCourseDetails(course);
    promptEnterToContinue(scanner);
    }
    
    private void displayCourseDetails(Course course) {
        System.out.println("\nUpdated Course Details:");
        System.out.println("Course ID: " + course.getCourseID());
        System.out.println("Course Name: " + course.getCourseName());
        System.out.println("Fee: $" + course.getFee());
        System.out.println("Credit Hours: " + course.getCreditHours());
        System.out.println("Course Type: " + course.getType());
        System.out.println();  // Add an extra line for better readability
    }
    
    public void displayCoursesByFaculty() {
        System.out.println("Courses listed by Faculty:");
        for (String facultyId : faculties.keySet()) {
            Faculty faculty = faculties.get(facultyId);
            System.out.println(faculty.getFacultyName() + " (" + faculty.getFacultyID() + "):");
            for (Course course : faculty.getCourses().values()) {
            System.out.println("\t" + course.getCourseID() + " - " + course.getCourseName());
            }
        }
    }
    
    public void displayCoursesForProgramme() {
        displayProgrammes(); 
        System.out.print("Enter the programme ID to view courses: ");
        String programmeId = scanner.nextLine().trim().toUpperCase();

        Programme selectedProgramme = programmes.get(programmeId);
        if (selectedProgramme != null) {
            System.out.println("Courses in " + selectedProgramme.getProgrammeName() + ":");
            HashMap<String, Course> associatedCourses = selectedProgramme.getCourses();
            if (associatedCourses.isEmpty()) {
                System.out.println("No courses are associated with this programme.");
            } else {
                for (Course course : associatedCourses.values()) {
                System.out.println(course.getCourseID() + " - " + course.getCourseName());
                }
            }
        } else {
            System.out.println("Programme not found. Please enter a valid programme ID.");
        }
    }
    
//    public void generateProgrammeCourseDistributionReport() {
//        System.out.println("Programme Course Distribution Report:");
//        System.out.println("-------------------------------------------------");
//        System.out.println(String.format("%-10s %-40s %-15s", "Programme ID", "Programme Name", "Number of Courses"));
//
//        for (Programme programme : programmes.values()) {
//            int numberOfCourses = programme.getCourses().size();
//            System.out.println(String.format("%-10s %-40s %-15d", 
//                programme.getProgrammeID(), 
//                programme.getProgrammeName(), 
//                numberOfCourses));
//        }
//    }
    
    //    public void generateFacultyCourseLoadReport() {
//        System.out.println("\n*");
//        System.out.println("            TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
//        System.out.println("                        COURSE MANAGEMENT SUBSYSTEM");
//        System.out.println();
//        System.out.println("                        FACULTY COURSE LOAD REPORT");
//        System.out.println("                   ========================================");
//        System.out.println();
//        System.out.println("Generated at: " + new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a").format(new Date()));
//        System.out.println();
//        System.out.println(String.format("%-15s %-50s %-15s", "FACULTY ID", "FACULTY NAME", "COURSES OFFERED"));
//        System.out.println("==========      ===============================================    ===============");
//
//        for (Faculty faculty : faculties.values()) {
//            int coursesOffered = faculty.getCourses().size(); // The number of courses that the faculty offers
//            System.out.println(String.format("%-15s %-50s %-15d", 
//                faculty.getFacultyID(), 
//                faculty.getFacultyName(), 
//                coursesOffered));
//        }
//
//        System.out.println("\n**");
//        System.out.println("                 END OF THE FACULTY COURSE LOAD REPORT\n");
//        promptEnterToContinue(scanner);
//    }
    
    public void generateCourseSummaryReport() {
        System.out.println("\n*");
        System.out.println("            TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
        System.out.println("                        COURSE MANAGEMENT SUBSYSTEM");
        System.out.println();
        System.out.println("                           COURSE SUMMARY REPORT");
        System.out.println("                ============================================");
        System.out.println();
        System.out.println("Generated at: " + new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a").format(new Date()));
        System.out.println();
        System.out.println(String.format("%-10s %-34s %-10s %-15s %-20s", "CODE", "COURSE NAME", "STATUS", "CREDIT HOURS", "PROGRAMMES OFFERED"));
        System.out.println(String.format("%-10s %-34s %-10s %-15s %-20s", "====", "===========", "======", "============", "=================="));
        
        // Keep track of courses with highest and lowest counts
        ListInterface<String> coursesWithMostProgrammes = new ArrayList<>();
        ListInterface<String> coursesWithLeastProgrammes = new ArrayList<>();
        ListInterface<String> coursesWithZeroProgrammes = new ArrayList<>();
        int maxProgrammes = 0;
        int minProgrammes = Integer.MAX_VALUE;
    
        for (Course course : courses.values()) {
            String status = course.getType().toString();
            int creditHours = course.getCreditHours();
            int offeredCount = course.getProgrammes().size(); // Number of programmes offering this course 
            
            // Update max and min programme counts
            if (offeredCount > maxProgrammes) {
                maxProgrammes = offeredCount;
                coursesWithMostProgrammes.clear();
                coursesWithMostProgrammes.add(course.getCourseID());
            }else if (offeredCount == maxProgrammes) {
                coursesWithMostProgrammes.add(course.getCourseID());
            }
            
            if (offeredCount < minProgrammes && offeredCount > 0) { // assuming I want to ignore courses with zero programmes
                minProgrammes = offeredCount;
                coursesWithLeastProgrammes.clear();
                coursesWithLeastProgrammes.add(course.getCourseID());
            } else if (offeredCount == minProgrammes) {
                coursesWithLeastProgrammes.add(course.getCourseID());
            }
            
            if (offeredCount == 0) {
                coursesWithZeroProgrammes.add(course.getCourseID());
            }
            
            System.out.println(String.format("%-10s %-34s %-10s %-15d %-20d", 
                course.getCourseID(), course.getCourseName(), status, creditHours, offeredCount));
        }
        
        System.out.println("\n**");
        System.out.println("Courses with the most number of programmes offered: " + String.join(", ", coursesWithMostProgrammes));
        System.out.println("Courses with the least number of programmes offered: " + String.join(", ", coursesWithLeastProgrammes));
        System.out.println("Courses with zero programmes offered: " + String.join(", ", coursesWithZeroProgrammes));
        System.out.println("");
        System.out.println("                    END OF THE COURSE SUMMARY REPORT\n");
        promptEnterToContinue(scanner);
    }
    
    public void generateCourseFinancialReport(){
        System.out.println("\n*");
        System.out.println("            TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
        System.out.println("                        COURSE MANAGEMENT SUBSYSTEM");
        System.out.println();
        System.out.println("                      COURSE FINANCIAL SUMMARY REPORT");
        System.out.println("                ============================================");
        System.out.println();
        System.out.println("Generated at: " + new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a").format(new Date()));
        System.out.println();
        System.out.println(String.format("| %-10s | %-40s | %-15s | %-15s | %-15s |", "Course ID", "Course Name", "Credit Hours", "Fee", "Total Revenue"));
        System.out.println("================================================================================");
        
        double totalRevenue = 0;
        for (Course course : courses.values()) {
            int enrolledStudents = studentRegistrationManagement.countEnrollmentsForCourse(course.getCourseID());
            double courseRevenue = course.getFee() * enrolledStudents;
            totalRevenue += courseRevenue;

        System.out.println(String.format("| %-10s | %-40s | %-15d | $%-14.2f | $%-14.2f |",
            course.getCourseID(),
            course.getCourseName(),
            course.getCreditHours(),
            course.getFee(),
            courseRevenue));
        }

        System.out.println("================================================================================");
        System.out.printf("Total Revenue from all courses: $%.2f\n", totalRevenue);
        System.out.println("================================================================================");
        System.out.println("               END OF THE COURSE FINANCIAL SUMMARY REPORT");
        System.out.println("Press <ENTER> key to continue...");

        scanner.nextLine(); // Wait for user to press Enter to continue
    }
    
    private String validateCourseId() {
        String courseId;
        while (true) {
            courseId = scanner.nextLine().trim().toUpperCase();
            if (courseId.matches("[A-Z]{4}\\d{4}")) break;
            System.out.print("Invalid course ID format. Please enter in the format 'BACS1234': ");
        }
        return courseId;
    }

    private double promptForDouble(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextDouble()) {
            scanner.next(); // Consume the invalid input
            System.out.print("Invalid input. Please enter a valid double value: ");
        }
        return scanner.nextDouble();
    }

    private int promptForInt(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            scanner.next(); // Consume the invalid input
            System.out.print("Invalid input. Please enter a valid integer value: ");
        }
        return scanner.nextInt();
    }

    private Course.courseType validateCourseType() {
        String courseType;
        while (true) {
            courseType = scanner.nextLine().trim().toUpperCase();
            try {
                return Course.courseType.valueOf(courseType);
            } catch (IllegalArgumentException e) {
                System.out.print("Invalid course type. Please enter MAIN or ELECTIVE: ");
            }
        }
    }

    // Method to filter and return courses by programme ID
    // Method to filter and return courses by programme ID
    public ListInterface<Course> getCoursesForProgramme(String programmeId) {
        ListInterface<Course> filteredCourses = new ArrayList<>();
        for (Course course : courses.values()) {  // Iterate through all courses stored in the HashMap
            if (course.getProgrammes().containsKey(programmeId)) { // Check if the programmeId is a key in the course's programmes HashMap
                filteredCourses.add(course);
            }
        }
        return filteredCourses;
    }
    
    public Course findCourseById(String courseId) {
        for (Course course : courses.values()) {  // Assuming 'courses' is a HashMap or similar collection stored in CourseManagement
            if (course.getCourseID().equals(courseId)) {
                return course;
            }
        }
        return null; // Return null if no course matches the ID
    }
    
    private void promptEnterToContinue(Scanner scanner) {
        System.out.println("Press Enter to continue...");
        scanner.nextLine();
    }
}