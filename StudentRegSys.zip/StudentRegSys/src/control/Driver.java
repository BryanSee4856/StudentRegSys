package control;

import adt.HashMap;
import java.util.Scanner;
import boundary.Menu;
import dao.CourseInitializer;
import dao.FacultyInitializer;
import dao.ProgrammeCourse;
import dao.SemesterInitializer;
import entity.Course;
import entity.Faculty;
import entity.Programme;

public class Driver {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Shared CourseInitializer for consistent data
            CourseInitializer courseInitializer = new CourseInitializer();
            // Initialize courses and programmes through the centralized ProgrammeCourse class
            ProgrammeCourse programmeCourse = new ProgrammeCourse();
            HashMap<String, Course> courses = programmeCourse.getCourses();
            HashMap<String, Programme> programmes = programmeCourse.getProgrammes();
            SemesterInitializer semesterInitializer = new SemesterInitializer(programmeCourse);
            
            FacultyInitializer facultyInitializer = FacultyInitializer.getInstance(courseInitializer);
            HashMap<String, Faculty> faculties = facultyInitializer.getFaculties();

            CourseManagement courseManager = new CourseManagement(courses, programmes, faculties, scanner, semesterInitializer, courseInitializer);            
            StudentRegistrationManagement regManager = new StudentRegistrationManagement(scanner, courseManager);
            TeachingAssignmentManagement tam = new TeachingAssignmentManagement(scanner, courseManager);
            courseManager.setStudentRegistrationManagement(regManager);
            
            int choice;
            do {
                String border = new String(new char[50]).replace('\0', '*');
                String menuTitle = " Student Management System ";
                int leftPadding = (border.length() - menuTitle.length()) / 2;
                String paddedTitle = new String(new char[leftPadding]).replace('\0', ' ') + menuTitle;

                // Print the menu with the borders
                System.out.println(border);
                System.out.println(paddedTitle );
                System.out.println(border);
                System.out.println("* 1. Student Registration Management       *");
                System.out.println("* 2. Course Management                     *");
                System.out.println("* 3. Teaching Assignment Management        *");
                System.out.println("* 0. Exit                                  *");
                System.out.println(border);
                System.out.print("Enter your choice: ");

                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1 :
                        Menu.StuRegManagementMenu(scanner, regManager);
                        break;
                    case 2 : 
                        Menu.CourseManagementMenu(scanner, courseManager);
                        break;
                    case 3 : 
                        Menu.TeachingAssignmentManagementMenu(scanner, tam);

                        break;
                    case 0 : 
                        System.out.println("Exiting program...");
                        break;
                    default :
                        System.out.println("Invalid choice. Please enter a number between 0 and 3.");
                        break;
                }
            } while (choice != 0);
        }catch (Exception e) {
        }
    }
}
