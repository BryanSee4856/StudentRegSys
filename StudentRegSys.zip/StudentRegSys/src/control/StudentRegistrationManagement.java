package control;

import entity.Student;
import adt.ArrayList;
import adt.ListInterface;
import dao.ProgrammeInitializer;
import dao.StudentInitializer;
import entity.Course;
import entity.Enrollment;
import entity.Programme;
import java.util.Scanner;
import utility.Validation;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class StudentRegistrationManagement {
    private ListInterface<Student> students;
    private CourseManagement courseManagement;  // Reference to CourseManagement
    private Scanner scanner;

    public StudentRegistrationManagement(Scanner scanner, CourseManagement courseManagement) {
        this.students = new ArrayList<>();
        this.courseManagement = courseManagement;
        this.scanner = scanner;
        loadPredefinedStudents();
    }

    private void loadPredefinedStudents() {
        StudentInitializer initializer = new StudentInitializer();
        ListInterface<Student> predefinedStudents = initializer.getStudents();
        for (Student student : predefinedStudents) {
            this.students.add(student);
        }
    }

    public void addStudent() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");

        // Centering the header "Add Student" between the lines of "==================="
        String header = "Add Student";
        int totalWidth = 76; // The width of the separator line
        int leftPadding = (totalWidth - header.length()) / 2;
        String formattedHeader = String.format("%" + leftPadding + "s%s", "", header);
        
        System.out.println("============================================================================");
        System.out.println(formattedHeader);
        System.out.println("============================================================================");

        StudentInitializer initializer = new StudentInitializer();
        String ic = Validation.promptForUniqueInput(scanner, "Enter Student IC (format: 123445-10-1169): ", "\\d{6}-\\d{2}-\\d{4}", "Invalid IC format. Please enter in the format 123445-10-1169.", initializer, "IC");

        // Collect Programme once
        String programme = Validation.promptForValidProgram(scanner, new ProgrammeInitializer());
        String id, programCodeFromID;

        // Loop until a valid ID is entered that matches the programme
        while (true) {
            id = Validation.promptForUniqueInput(scanner, "Enter Student ID (format: 12XXX13530): ", "\\d{2}[A-Z]{3}\\d{5}", "Invalid student ID format. Please enter in the format 12XXX13530.", initializer, "ID");

            // Convert the ID to uppercase for case-insensitive comparison
            id = id.toUpperCase();

            // Extract the program code from the Student ID
            programCodeFromID = id.substring(2, 5);

            if (programCodeFromID.equals(programme)) {
                break; // Exit the loop if the program code matches
            } else {
                System.out.println("Error: The program code in the Student ID (" + programCodeFromID + ") does not match the Programme ID (" + programme + "). Please enter a correct Student ID.");
            }
        }

        // Continue gathering other information after validation
        String name = Validation.promptForInput(scanner, "Enter Student Name: ", ".+");
        String email = Validation.promptForInput(scanner, "Enter Student Email (format: xxx@student.tarc.edu.my): ", "[\\w]+@student\\.tarc\\.edu\\.my");

        // Create and add the new student
        Student newStudent = new Student(id, name, ic, email, programme);
        if (students.add(newStudent)) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Failed to add student.");
        }
        // Print three empty lines after method execution        
        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }

    public boolean removeStudent() {
        // Print three empty lines before method execution
        System.out.println("============================================================================");
        System.out.println("                               Remove Student");
        System.out.println("============================================================================");

        do {
            System.out.print("Enter Student ID to remove or press 0 to return to the menu: ");
            String id = scanner.nextLine().trim().toUpperCase(); // Convert input to upper case for case-insensitive comparison

            if (id.equals("0")) {
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return false;  // Exiting without removing any student
            }

            for (int i = 0; i < students.getNumberOfEntries(); i++) {
                Student student = students.getEntry(i + 1); // Assuming list is 1-indexed
                // Also convert stored student IDs to upper case for comparison
                if (student.getStudentId().toUpperCase().equals(id)) {
                    System.out.print("Are you sure you want to remove this student? (1 for Yes, 2 for No): ");
                    int confirmation = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline left after number input
                    if (confirmation == 1) {
                        students.remove(i + 1); // Remove the student
                        System.out.println("Student removed successfully.");
                        System.out.println("============================================================================");
                        System.out.println("\n");
                        return true; // Student was successfully removed
                    } else {
                        System.out.println("Student removal canceled.");
                        System.out.println("============================================================================");
                        System.out.println("\n");
                        return false; // Cancel the removal
                    }
                }
            }

            System.out.println("No student found with ID: " + id);
            System.out.println("Press any Num to try again, 0 to return to the main menu.");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline left after number
            if (option == 0) {
                System.out.println("============================================================================");
                return false; // Exiting without removing any student
            }
        } while (true);
    }

    public void amendStudent() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                              Amend Student");
        System.out.println("============================================================================");

        while (true) {
            System.out.print("Enter Student ID to amend details or press 0 to return to the main menu: ");
            String id = scanner.nextLine().trim();

            if (id.equals("0")) {
                System.out.println("Returning to the main menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;
            }

            Student student = findStudentById(id.toUpperCase()); // Assuming IDs are case-insensitive

            if (student == null) {
                System.out.println("No student found with ID: " + id + ". Please try again.");
            } else {
                System.out.println("\nSelected Student: " + student);
                System.out.println("");
                System.out.println("What detail would you like to amend?");
                System.out.println("1. Name");
                System.out.println("2. Email");
                System.out.println("3. Programme");
                System.out.print("Enter choice (1-3) or press 0 to return: ");

                String choiceInput = scanner.nextLine();
                if (choiceInput.equals("0")) {
                    System.out.println("Returning to the main menu...");
                    // Print three empty lines after method execution
                    System.out.println("============================================================================");
                    System.out.println("\n\n\n");
                    return;
                }

                int choice;
                try {
                    choice = Integer.parseInt(choiceInput);
                } catch (NumberFormatException e) {
                    System.out.print("Invalid input. Please enter a number between 1 and 3: ");
                    continue;
                }

                if (choice < 1 || choice > 3) {
                    System.out.print("Invalid choice. Please enter a number between 1 and 3: ");
                    continue;
                }

                System.out.println("You chose to amend " + (choice == 1 ? "Name" : choice == 2 ? "Email" : "Programme"));
                System.out.print("Enter new value: ");
                String newValue = scanner.nextLine();

                System.out.print("Are you sure you want to update this information? (1 = Yes, 2 = No): ");
                String confirmation = scanner.nextLine();
                if (!confirmation.equals("1")) {
                    System.out.println("Update cancelled. No changes were made.");
                    continue;
                }

                switch (choice) {
                    case 1 -> {
                        student.setName(newValue);
                        System.out.println("Name updated successfully.");
                    }
                    case 2 -> {
                        student.setEmail(newValue);
                        System.out.println("Email updated successfully.");
                    }
                    case 3 -> {
                        String oldProgramCode = student.getStudentId().substring(2, 5);
                        student.setProgramme(newValue.toUpperCase());
                        if (!oldProgramCode.equals(newValue.substring(0, 3))) {
                            String newId = id.substring(0, 2) + newValue.substring(0, 3) + id.substring(5);
                            student.setStudentId(newId);
                            System.out.println("Updating Student ID to reflect new programme...");
                        }
                        System.out.println("Programme updated successfully.");
                    }
                }
                System.out.println("\nUpdated Student Details: " + student);
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                break; // Exit after updating
            }
        }
    }

    public void addStudentCourse() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                       Course Registration for Students");
        System.out.println("============================================================================");

        String studentId;
        Student student;

        while (true) {
            System.out.print("Enter Student ID for course registration or press 0 to return: ");
            studentId = scanner.nextLine().trim();

            if (studentId.equals("0")) {
                System.out.println("Returning to the previous menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;
            }

            student = findStudentById(studentId.toUpperCase()); // Assuming student IDs are case insensitive.

            if (student != null) {
                break;
            }

            System.out.println("No student found with ID: " + studentId + ". Please try again or press 0 to exit.");
        }

        // Display courses from the student's programme
        ListInterface<Course> availableCourses = courseManagement.getCoursesForProgramme(student.getProgramme());
        if (availableCourses.isEmpty()) {
            System.out.println("No available courses for this programme.");
            // Print three empty lines after method execution
            System.out.println("============================================================================");
            System.out.println("\n\n\n");
            return;
        }

        System.out.println("\nAvailable Courses:");
        for (Course course : availableCourses) {
            System.out.println(course.getCourseID() + " - " + course.getCourseName());
        }

        OUTER:
        while (true) {
            System.out.println("\n--------------------------------------------");
            System.out.print("Enter Course ID to register the student or press 0 to return: ");
            String courseId = scanner.nextLine().trim();
            if (courseId.equals("0")) {
                System.out.println("Returning to the previous menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;
            }
            Course selectedCourse = findCourseById(courseId, availableCourses);
            if (selectedCourse == null) {
                System.out.println("Invalid Course ID. Please try again or press 0 to exit.");
            } else {
                if (isAlreadyEnrolled(student, selectedCourse)) {
                    System.out.println("Student is already registered for this course. Please choose a different course.");
                    continue;  // Skip adding the course and allow choosing another.
                }
                System.out.println("\nSelected Course:");
                System.out.println("Course ID: " + selectedCourse.getCourseID());
                System.out.println("Course Name: " + selectedCourse.getCourseName());
                System.out.println("Confirm registration:");
                System.out.println("1. Yes");
                System.out.println("2. No");
                System.out.print("Enter your choice: ");
                int confirm = scanner.nextInt();
                scanner.nextLine();  // Consume the newline character.
                switch (confirm) {
                    case 1 -> {
                        String registrationType = Validation.promptForRegistrationType(scanner);
                        Enrollment newEnrollment = new Enrollment(selectedCourse, registrationType);
                        student.addEnrollment(newEnrollment);
                        System.out.println("Student successfully added to the course.");
                        // Print three empty lines after method execution
                        System.out.println("============================================================================");
                        System.out.println("\n\n\n");
                        break OUTER;  // Exit the loop after successful registration
                    }
                    case 2 -> {
                        System.out.println("Registration cancelled.");
                        // Print three empty lines after method execution
                        System.out.println("============================================================================");
                        System.out.println("\n\n\n");
                        return;  // Exit if user decides not to proceed
                    }
                    default -> System.out.println("Invalid choice. Please enter 1 for Yes or 2 for No.");
                }
            }
        }
    }

    private boolean isAlreadyEnrolled(Student student, Course course) {
        for (Enrollment enrollment : student.getEnrollments()) {
            if (enrollment.getCourse().getCourseID().equals(course.getCourseID())) {
                return true;
            }
        }
        return false;
    }

    public void removeStudentCourse() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                         Course Removal for Students");
        System.out.println("============================================================================");

        String studentId;
        Student student;

        while (true) {
            System.out.print("Enter the Student ID to remove a course or press 0 to return: ");
            studentId = scanner.nextLine().trim();

            if (studentId.equals("0")) {
                System.out.println("\nReturning to the main menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;
            }

            student = findStudentById(studentId.toUpperCase());

            if (student != null) {
                break;
            }

            System.out.println("\nNo student found with ID: " + studentId + ". Please try again or press 0 to exit.");
        }

        ListInterface<Enrollment> enrollments = student.getEnrollments();
        if (enrollments.isEmpty()) {
            System.out.println("\nThis student is not registered for any courses.");
            System.out.println("============================================================================");
            System.out.println("\n\n\n");
            return;
        }

        System.out.println("\nCourses registered by " + student.getName() + ":");
        for (Enrollment enrollment : enrollments) {
            System.out.println("Course ID: " + enrollment.getCourse().getCourseID() +
                               " - Course Name: " + enrollment.getCourse().getCourseName() +
                               " - Registration Type: " + enrollment.getRegistrationType());
        }

        while (true) {
            System.out.print("\nEnter the Course ID to remove or press 0 to return: ");
            String courseId = scanner.nextLine().trim();

            if (courseId.equals("0")) {
                System.out.println("\nReturning to the main menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;
            }

            boolean found = false;
            for (int i = 0; i < enrollments.getNumberOfEntries(); i++) {
                Enrollment enrollment = enrollments.getEntry(i + 1);
                if (enrollment.getCourse().getCourseID().equals(courseId)) {
                    System.out.print("\nAre you sure you want to remove this course? (1 for Yes, 2 for No): ");
                    int confirmation = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline left after the number input.

                    if (confirmation == 1) {
                        enrollments.remove(i + 1);  // Remove the enrollment.
                        System.out.println("\nCourse removed successfully.");
                        found = true;
                        break;
                    } else if (confirmation == 2) {
                        System.out.println("\nCourse removal cancelled.");
                        // Print three empty lines after method execution
                        System.out.println("============================================================================");
                        System.out.println("\n\n\n");
                        return;
                    } else {
                        System.out.println("\nInvalid choice. Please enter 1 for Yes or 2 for No.");
                    }
                }
            }

            if (!found) {
                System.out.println("Course ID not found in the student's enrollments. Please try again or press 0 to exit.");
            } else {
                break;  // Exit loop after successful removal or cancellation.
            }
        }
        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }

    // ===============================================================================================================================//
    public void studentRegisteredCourse() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                        Viewing Registered Courses");
        System.out.println("============================================================================");

        while (true) {
            System.out.println("Choose the viewing mode:");
            System.out.println("1 - By Student");
            System.out.println("2 - By Course");
            System.out.println("0 - Return to the previous menu");
            System.out.print("Enter your choice (1, 2, or 0): ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline left-over

            switch (choice) {
                case 1 -> {
                    showByStudent();
                    // Print three empty lines after method execution
                    System.out.println("============================================================================");
                    System.out.println("\n\n\n");
                    return; // Exit after operation
                }
                case 2 -> {
                    showByCourse();
                    // Print three empty lines after method execution
                    System.out.println("============================================================================");
                    System.out.println("\n\n\n");
                    return; // Exit after operation
                }
                case 0 -> {
                    System.out.println("Returning to the previous menu...");
                    // Print three empty lines after method execution
                    System.out.println("============================================================================");
                    System.out.println("\n\n\n");
                    return; // Return to the previous menu
                }
                default -> System.out.println("Invalid choice. Please enter 1, 2, or 0.");
            }
        }
    }

    private void showByStudent() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                               Student Course Details");
        System.out.println("============================================================================");

        String studentId;
        Student student;

        while (true) {
            System.out.print("Enter the Student ID or press 0 to go back: ");
            studentId = scanner.nextLine().trim();

            if (studentId.equals("0")) {
                System.out.println("Returning to the previous menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return; // Return to the previous menu
            }

            student = findStudentById(studentId);
            if (student != null) {
                break; // Break the loop if a valid student is found
            }

            System.out.println("No student found with ID: " + studentId + ". Please try again or press 0 to exit.");
        }

        System.out.println("\n--- Student Details ---");
        System.out.println("Student ID: " + student.getStudentId() + ", Name: " + student.getName());
        ListInterface<Enrollment> enrollments = student.getEnrollments();
        if (enrollments.isEmpty()) {
            System.out.println("This student has not registered for any courses.");
        } else {
            // Print table header
            System.out.println(String.format("%-10s %-30s %-20s %-20s", "Course ID", "Course Name", "Course Type", "Registration Type"));
            System.out.println("-----------------------------------------------------------------------------------");

            // Print table rows
            for (Enrollment enrollment : enrollments) {
                Course course = enrollment.getCourse();
                System.out.println(String.format("%-10s %-30s %-20s %-20s", 
                    course.getCourseID(), 
                    course.getCourseName(),
                    course.getType(), 
                    enrollment.getRegistrationType()));
            }
        }
    }

    private void showByCourse() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                                Course Details");
        System.out.println("============================================================================");

        String courseId;
        Course selectedCourse = null;

        while (true) {
            System.out.print("Enter the Course ID or press 0 to go back: ");
            courseId = scanner.nextLine().trim();

            if (courseId.equals("0")) {
                System.out.println("Returning to the previous menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return; // Return to the previous menu
            }

            // Determine if any student is registered in the course to get the course details
            for (Student student : students) {
                ListInterface<Enrollment> enrollments = student.getEnrollments();
                for (Enrollment enrollment : enrollments) {
                    if (enrollment.getCourse().getCourseID().equals(courseId)) {
                        selectedCourse = enrollment.getCourse(); // Set the course details
                        break; // Break as soon as you find the course
                    }
                }
                if (selectedCourse != null) break;
            }

            if (selectedCourse == null) {
                System.out.println("No student found registered in Course ID: " + courseId + ". Please try again or press 0 to exit.");
            } else {
                break; // Break the loop if a valid course is found
            }
        }

        // Display the course details once
        System.out.println("\n--- Course Details ---");
        System.out.println("Course ID: " + selectedCourse.getCourseID() +
                           ", Course Name: " + selectedCourse.getCourseName() +
                           ", Course Type: " + selectedCourse.getType());

        // Now display all students enrolled in this course
        System.out.println(String.format("\n%-12s %-25s %-20s", "Student ID", "Name", "Registration Type"));
        System.out.println("-------------------------------------------------------------------");

        boolean studentFound = false;
        for (Student student : students) {
            ListInterface<Enrollment> enrollments = student.getEnrollments();
            for (Enrollment enrollment : enrollments) {
                if (enrollment.getCourse().getCourseID().equals(courseId)) {
                    System.out.println(String.format("%-12s %-25s %-20s", 
                        student.getStudentId(), 
                        student.getName(), 
                        enrollment.getRegistrationType()));
                    studentFound = true;
                }
            }
        }

        if (!studentFound) {
            System.out.println("\tNo students currently registered for this course.");
            System.out.println("============================================================================");
            System.out.println("\n\n\n");
        }
    }
    //================================================================================================================================//
    
    public void FiltersStudents() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                           Filtered Students");
        System.out.println("============================================================================");

        if (students.isEmpty()) {
            System.out.println("No students are currently registered.");
            // Print three empty lines after method execution
            System.out.println("============================================================================");
            System.out.println("\n\n\n");
            return;
        }

        String filterRegType = Validation.promptForRegistrationType(scanner);
        String filterCourseType = Validation.promptForCourseType(scanner);

        boolean found = false;
        System.out.println("Filtered students based on '" + filterRegType + "' registration type and '" + filterCourseType + "' course type:");
        // Enhanced table header with padded and centered column titles
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-20s | %-30s | %-15s | %-30s |\n", "Student ID", "Name", "Email", "Course ID", "Course Name");
        System.out.println("-------------------------------------------------------------------------------------------------");

        for (Student student : students) {
            ListInterface<Enrollment> enrollments = student.getEnrollments();
            for (Enrollment enrollment : enrollments) {
                Course course = enrollment.getCourse();
                if (enrollment.getRegistrationType().equalsIgnoreCase(filterRegType) &&
                    course.getType().name().equalsIgnoreCase(filterCourseType)) {
                    // Enhanced row formatting for clarity and alignment
                    System.out.printf("| %-10s | %-20s | %-30s | %-15s | %-30s |\n",
                        student.getStudentId(), 
                        student.getName(), 
                        student.getEmail(),
                        course.getCourseID(),
                        course.getCourseName());
                    found = true;
                    break; // Assuming you only want to list each student once
                }
            }
        }

        System.out.println("-------------------------------------------------------------------------------------------------");

        if (!found) {
            System.out.println("No students found matching the specified criteria.");
        }
        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }

    public void CalculateFee() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                           Calculate Student Fee");
        System.out.println("============================================================================");

        String studentId;
        Student student;

        while (true) {
            System.out.print("Enter the Student ID to calculate the fee or press 0 to go back: ");
            studentId = scanner.nextLine().trim();

            if (studentId.equals("0")) {
                System.out.println("\nReturning to the previous menu...");
                // Print three empty lines after method execution
                System.out.println("============================================================================");
                System.out.println("\n\n\n");
                return;  // Return to the previous menu
            }

            student = findStudentById(studentId);
            if (student != null) {
                break;  // Break the loop if a valid student is found
            }

            System.out.println("\nNo student found with ID: " + studentId + ". Please try again or press 0 to exit.");
        }

        ListInterface<Enrollment> enrollments = student.getEnrollments();
        if (enrollments.isEmpty()) {
            System.out.println("\nThis student has not registered for any courses.");
            System.out.println("============================================================================");
            System.out.println("\n\n\n");
            return;
        }

        double totalFee = 0;
        for (Enrollment enrollment : enrollments) {
            totalFee += enrollment.getCourse().getFee();  // Calculate total fee
        }

        // Adding a visual separator for clarity
        System.out.println("\n-------------------------------------------------");
        System.out.printf("Total fee for %s (%s) is: $%.2f\n", student.getName(), student.getStudentId(), totalFee);
        System.out.println("-------------------------------------------------");

        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }
    
    public void StudentReport() {
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("                  TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
        System.out.println("                                  STUDENT MANAGEMENT SUBSYSTEM");
        System.out.println("                                   STUDENT REPORT MENU");
        System.out.println("============================================================================");

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1 - Generate Student Course Registration Report");
            System.out.println("2 - Generate Fees Summary Report");
            System.out.println("0 - Go Back to Previous Menu");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    generateStudentReport();
                    break;
                case "2":
                    generateFeesReport();
                    break;
                case "0":
                    System.out.println("Returning to the previous menu...");
                    // Print three empty lines after method execution
                    System.out.println("============================================================================");
                    System.out.println("\n\n\n");
                    return; // This will exit the method and thus go back to the previous menu
                default:
                    System.out.println("Invalid choice, please enter 1, 2, or 0.");
                    continue;
            }
        }
    }
    
    public void generateStudentReport() {
        // Print three empty lines before method execution
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("       TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
        System.out.println("                        STUDENT MANAGEMENT SUBSYSTEM");
        System.out.println("                   STUDENT COURSE REGISTRATION SUMMARY");
        System.out.println("============================================================================");

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a");
        String reportDate = dateFormat.format(new Date());
        System.out.println("\nGenerated at: " + reportDate + "\n");

        // Initialize programme count hashmap
        ProgrammeInitializer programmeInitializer = new ProgrammeInitializer();
        HashMap<String, Integer> programmeStudentCount = new HashMap<>();
        for (Programme programme : programmeInitializer.getProgrammes().values()) {
            programmeStudentCount.put(programme.getProgrammeID(), 0);
        }

        // Table headers for student list
        System.out.println("================================================================================");
        System.out.println(String.format("| %-20s | %-10s | %-30s | %-19s |", "Student Name", "Student ID", "Email", "Courses Registered"));
        System.out.println("================================================================================");

        // Variables to track students with most and least registrations
        Student mostEnrolledStudent = null;
        Student leastEnrolledStudent = null;
        int maxEnrollments = 0;
        int minEnrollments = Integer.MAX_VALUE;

        // Process students
        for (Student student : students) {
            int enrollmentCount = student.getEnrollments().getNumberOfEntries();
            // Update counts
            programmeStudentCount.put(student.getProgramme(), programmeStudentCount.getOrDefault(student.getProgramme(), 0) + 1);
            // Update students with most and least registrations
            if (enrollmentCount > maxEnrollments) {
                maxEnrollments = enrollmentCount;
                mostEnrolledStudent = student;
            }
            if (enrollmentCount < minEnrollments) {
                minEnrollments = enrollmentCount;
                leastEnrolledStudent = student;
            }
            // Print student information
            System.out.println(String.format("| %-20s | %-10s | %-30s | %-19d |", student.getName(), student.getStudentId(), student.getEmail(), enrollmentCount));
        }
        System.out.println("================================================================================");

        // Programme summary header
        System.out.println("\nNumber of students per programme:");
        System.out.println(String.format("| %-15s | %-50s | %-17s |", "PROGRAMME ID", "PROGRAMME NAME", "STUDENTS ENROLLED"));
        System.out.println("================================================================================");

        // Programme summary rows
        for (String programmeId : programmeStudentCount.keySet()) {
            String programmeName = programmeInitializer.getProgrammeNameById(programmeId); // Get the programme name
            int studentCount = programmeStudentCount.get(programmeId);
            System.out.println(String.format("| %-15s | %-50s | %-17d |", programmeId, programmeName, studentCount));
        }
        System.out.println("================================================================================");

        // Print most and least enrolled students
        printEnrollmentDetails("Student with the most course registrations:", mostEnrolledStudent);
        printEnrollmentDetails("Student with the fewest course registrations:", leastEnrolledStudent);

        System.out.println("END OF THE STUDENT COURSE REGISTRATION SUMMARY");
        System.out.print("Press <ENTER> key to go back to the previous menu...");

        // Wait for the user to press Enter
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine(); // This will pause the execution until the user presses Enter

        // Print three empty lines after method execution
        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }
    
    public void generateFeesReport() {
        System.out.println("\n\n\n");
        System.out.println("============================================================================");
        System.out.println("       TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
        System.out.println("                        STUDENT MANAGEMENT SUBSYSTEM");
        System.out.println("                          STUDENT FEES SUMMARY REPORT");
        System.out.println("============================================================================");

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a");
        String reportDate = dateFormat.format(new Date());
        System.out.println("\nGenerated at: " + reportDate + "\n");

        System.out.println("================================================================================");
        System.out.println(String.format("| %-20s | %-10s | %-30s | %-17s |", "Student Name", "Student ID", "Email", "Total Fees ($)"));
        System.out.println("================================================================================");

        double maxFees = 0;
        double minFees = Double.MAX_VALUE;
        Student highestFeeStudent = null;
        Student lowestFeeStudent = null;

        for (Student student : students) {
            double totalFees = 0;
            for (Enrollment enrollment : student.getEnrollments()) {
                if (enrollment != null && enrollment.getCourse() != null) {
                    totalFees += enrollment.getCourse().getFee();
                }
            }

            System.out.println(String.format("| %-20s | %-10s | %-30s | $%-16.2f |", student.getName(), student.getStudentId(), student.getEmail(), totalFees));

            if (totalFees > maxFees) {
                maxFees = totalFees;
                highestFeeStudent = student;
            }
            if (totalFees < minFees) {
                minFees = totalFees;
                lowestFeeStudent = student;
            }
        }
        System.out.println("================================================================================");

        // Print highest fee student details
        if (highestFeeStudent != null) {
            System.out.println("\nStudent with the highest fees:");
            System.out.println("================================================================================");
            System.out.println(String.format("| %-20s | %-10s | %-30s | $%-16.2f |", highestFeeStudent.getName(), highestFeeStudent.getStudentId(), highestFeeStudent.getEmail(), maxFees));
            System.out.println("================================================================================");
        }

        // Print lowest fee student details
        if (lowestFeeStudent != null) {
            System.out.println("\nStudent with the lowest fees:");
            System.out.println("================================================================================");
            System.out.println(String.format("| %-20s | %-10s | %-30s | $%-16.2f |", lowestFeeStudent.getName(), lowestFeeStudent.getStudentId(), lowestFeeStudent.getEmail(), minFees));
            System.out.println("================================================================================");
        }

        System.out.println("END OF THE STUDENT FEES SUMMARY REPORT");
        System.out.print("Press <ENTER> key to go back to the previous menu...");

        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();  // Wait for the user to press Enter

        // Print three empty lines after method execution
        System.out.println("============================================================================");
        System.out.println("\n\n\n");
    }

    private void printEnrollmentDetails(String title, Student student) {
        if (student != null) {
            System.out.println("\n" + title);
            System.out.println(String.format("| %-20s | %-10s | %-30s | %-19s |", "Student Name", "Student ID", "Email", "Courses Registered"));
            System.out.println("--------------------------------------------------------------------------------");
            System.out.println(String.format("| %-20s | %-10s | %-30s | %-19d |", 
                student.getName(), 
                student.getStudentId(), 
                student.getEmail(), 
                student.getEnrollments().getNumberOfEntries()));

            System.out.println("Courses registered:");
            if (!student.getEnrollments().isEmpty()) {
                for (Enrollment enrollment : student.getEnrollments()) {
                    Course course = enrollment.getCourse();
                    System.out.println("| " + course.getCourseID() + " - " + course.getCourseName());
                }
            } else {
                System.out.println("| None");
            }
            System.out.println("--------------------------------------------------------------------------------");
        }
    }

    private Course findCourseById(String courseId, ListInterface<Course> courses) {
        for (int i = 0; i < courses.getNumberOfEntries(); i++) {
            Course course = courses.getEntry(i + 1); // Assuming the list is 1-indexed
            if (course.getCourseID().equals(courseId)) {
                return course;
            }
        }
        return null; // Return null if no course matches the ID
    }

    private Student findStudentById(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                return student;
            }
        }
        return null;
    }

    public void listStudents() {
        // Print three empty lines before method execution
        System.out.println("============================================================================");
        System.out.println("                           List of All Registered Students");
        System.out.println("============================================================================");

        if (students.isEmpty()) {
            System.out.println("No students are currently registered.");
        } else {
            System.out.println("Listing all registered students:");
            for (Student student : students) {
                System.out.println(student);
            }
        }

        // Print three empty lines after method execution
        System.out.println("============================================================================");
        System.out.println("\n");
    }
    
    public void closeScanner() {
        if (scanner != null) {
            scanner.close();
        }
    }
    
    public int countEnrollmentsForCourse(String courseId) {
        int count = 0;
        for (Student student : students) { // Assuming `students` is the list of all students
            for (Enrollment enrollment : student.getEnrollments()) {
                if (enrollment.getCourse().getCourseID().equals(courseId)) {
                    count++;
                }
            }
        }
        return count;
    }
}