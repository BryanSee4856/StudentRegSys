/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.Scanner;
import adt.LinkedList;
import dao.CourseInitializer;
import dao.TutorInitializer;
import dao.TutorialGroupInitializer;
import entity.Course;
import entity.RoleType;
import entity.Tutor;
import entity.TutorialGroup;
import static boundary.Menu.printMenuHeader;
import static boundary.Menu.printMenuItem;
import static boundary.Menu.printMenuFooter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TeachingAssignmentManagement {
    private LinkedList<Course> courseList;
    private LinkedList<Tutor> tutors; 
    private LinkedList<TutorialGroup> tutorialGroups; 
    private CourseManagement courseManagement;
    private Scanner scanner;
    
    public TeachingAssignmentManagement(Scanner scanner, CourseManagement courseManagement) {
        this.courseManagement = courseManagement;
        this.scanner = scanner;
        initializeData();
    }

    private void initializeData() {
        CourseInitializer courseInit = new CourseInitializer();
        TutorInitializer tutorInit = new TutorInitializer(courseInit.getCourseList());
        TutorialGroupInitializer groupInit = new TutorialGroupInitializer();

        this.courseList = courseInit.getCourseList();
        this.tutors = tutorInit.getTutors();
        this.tutorialGroups = groupInit.getTutorialGroups();
    }
    
    private void promptEnterToContinue(Scanner scanner) {
        System.out.println("Press Enter to continue...");
        scanner.nextLine();
    }
    public void displayTutors() {
        printMenuHeader("List of Tutors");
        for (Tutor tutor : tutors) {
            printMenuItem("ID: " + tutor.getId() + ", Name: " + tutor.getName());
        }
        printMenuFooter();
    }
    public void displayTutorialGroups() {
    if (tutorialGroups == null || tutorialGroups.isEmpty()) {
        System.out.println("No tutorial groups available or list is not initialized.");
        return;
    }

    System.out.println("List of Tutorial Groups:");
    for (TutorialGroup group : tutorialGroups) {
        if (group != null) {
            System.out.println("Group ID: " + group.getGroupId());
        } else {
            System.out.println("Encountered a null group in the list.");
        }
    }
}
    public void assignTutorToCourse(Scanner scanner) {
    Tutor tutor = null;
    Course course = null;
    while (tutor == null) {
        displayTutors();
        System.out.print("Enter Tutor ID: ");
        String tutorId = scanner.nextLine().trim();
        tutor = findTutorById(tutorId);
        if (tutor == null) {
            System.out.println("Tutor not found. Please check the Tutor ID and try again.");
            promptEnterToContinue(scanner);
        }
    }
    while (course == null) {
            courseManagement.displayCourses();
        System.out.print("Enter Course ID: ");
        String courseId = scanner.nextLine().trim();
        course = findCourseById(courseId);
        if (course == null) {
            System.out.println("Course not found. Please check the Course ID and try again.");
            promptEnterToContinue(scanner);
        }
    }

    course.addTutor(tutor);
    System.out.println("Tutor " + tutor.getName() + " has been successfully assigned to course " + course.getCourseName() + ".");
    promptEnterToContinue(scanner);
}

    private Tutor findTutorById(String tutorId) {
    for (Tutor tutor : this.tutors) { 
        if (tutor.getId().trim().equalsIgnoreCase(tutorId.trim())) {
            return tutor;
        }
    }
    return null;
    }

    private Course findCourseById(String courseId) {
    for (Course course : this.courseList) { 
        if (course.getCourseID().trim().equalsIgnoreCase(courseId.trim())) {
            return course;
        }
    }
    return null;
    }

    public void setCourses(LinkedList<Course> courses) {
        this.courseList = courses;
    }

    public void setTutors(LinkedList<Tutor> tutors) {
        this.tutors = tutors;
    }
    
    public void assignTutorialGroupToTutor() {

        Tutor assignedTutor = null;
        while (assignedTutor == null) {
            displayTutors();
            System.out.print("Enter Tutor ID: ");
            String tutorId = scanner.nextLine();

            for (Tutor tutor : tutors) {
                if (tutor.getId().equals(tutorId)) {
                    assignedTutor = tutor;
                    break;
                }
            }

            if (assignedTutor == null) {
                System.out.println("Invalid Tutor ID. Please try again.");
                promptEnterToContinue(scanner);
            }
        }

        TutorialGroup assignedGroup = null;
        while (assignedGroup == null) {
            printMenuHeader("List of Tutorial Groups:  ");
            for (TutorialGroup group : tutorialGroups) {
                System.out.println("Group ID: " + group.getGroupId());
            }
            printMenuFooter();


            System.out.print("Enter Tutorial Group ID: ");
            String groupId = scanner.nextLine();

            for (TutorialGroup group : tutorialGroups) {
                if (group.getGroupId().equals(groupId)) {
                    assignedGroup = group;
                    break;
                }
            }

            if (assignedGroup == null) {
                System.out.println("Invalid Tutorial Group ID. Please try again.");
                promptEnterToContinue(scanner);
            }
        }

        if (assignedTutor != null && assignedGroup != null) {
            assignedGroup.addTutor(assignedTutor);
            System.out.println("Assignment Successful: " + assignedTutor.getName() + " to " + assignedGroup.getGroupId());
            promptEnterToContinue(scanner);
        }
    }
        public void assignTutorToTutorialGroupInCourse() {
        Scanner scanner = new Scanner(System.in);

        // Display courses and prompt for selection
        printMenuHeader("Available Courses");
        for (Course course : courseList) {
            System.out.println("Course ID: " + course.getCourseID() + ", Name: " + course.getCourseName());
        }
        printMenuFooter();
        System.out.print("Enter Course ID: ");
        String courseId = scanner.nextLine();
        Course selectedCourse = null;
        for (Course course : courseList) {
            if (course.getCourseID().equals(courseId)) {
                selectedCourse = course;
                break;
            }
        }
        if (selectedCourse == null) {
            System.out.println("Invalid Course ID. Please try again.");
            promptEnterToContinue(scanner);
            return;
        }
        LinkedList<TutorialGroup> tutorialGroups = selectedCourse.getTutorialGroups();

        printMenuHeader("Available Tutorial Groups for " + selectedCourse.getCourseName());
        for (TutorialGroup group : tutorialGroups) {
            System.out.println("Group ID: " + group.getGroupId());
        }
        printMenuFooter();
        System.out.print("Enter Tutorial Group ID: ");
        String groupId = scanner.nextLine();
        TutorialGroup selectedGroup = null;
        for (TutorialGroup group : tutorialGroups) {
            if (group.getGroupId().equals(groupId)) {
                selectedGroup = group;
                break;
            }
        }
        if (selectedGroup == null) {
            System.out.println("Invalid Tutorial Group ID. Please try again.");
            promptEnterToContinue(scanner);
            return;
        }

        printMenuHeader("Available Tutors");
        for (Tutor tutor : tutors) {
            System.out.println("Tutor ID: " + tutor.getId() + ", Name: " + tutor.getName());
        }
        printMenuFooter();
        System.out.print("Enter Tutor ID: ");
        String tutorId = scanner.nextLine();
        Tutor selectedTutor = null;
        for (Tutor tutor : tutors) {
            if (tutor.getId().equals(tutorId)) {
                selectedTutor = tutor;
                break;
            }
        }
        if (selectedTutor == null) {
            System.out.println("Invalid Tutor ID. Please try again.");
            promptEnterToContinue(scanner);
            return;
        }

        if (selectedGroup.addTutor(selectedTutor)) {
            System.out.println("Assignment Successful: " + selectedTutor.getName() + " to " + selectedGroup.getGroupId() + " in " + selectedCourse.getCourseName());
            promptEnterToContinue(scanner);
        } else {
            System.out.println("Failed to add tutor to the group.");
            promptEnterToContinue(scanner);
        }
    }
    public adt.LinkedList<Course> searchCoursesByTutorId(String tutorId) {
        if (tutorId == null || tutorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Tutor ID cannot be empty.");
        }

        for (Tutor tutor : tutors) {
            if (tutor.getId().equals(tutorId)) {
                return tutor.getCourses();
            }
        }
        return null;
    }

public void performCourseSearch() {
    displayTutors();
    System.out.print("Enter Tutor ID: ");
    String tutorId = scanner.nextLine();

    try {
        adt.LinkedList<Course> courses = searchCoursesByTutorId(tutorId);
        if (courses == null) {
            System.out.println("No tutor found with ID: " + tutorId);
            promptEnterToContinue(scanner);
        } else if (courses.isEmpty()) {
            System.out.println("No courses assigned to this tutor.");
            promptEnterToContinue(scanner);
        } else {
            System.out.println("Courses managed by Tutor ID " + tutorId + ":");
            for (Course course : courses) {
                System.out.println("Course ID: " + course.getCourseID() + ", Course Name: " + course.getCourseName());
            }
        }
        promptEnterToContinue(scanner);
    } catch (IllegalArgumentException e) {
        System.out.println(e.getMessage());
    }
}

    public LinkedList<Tutor> findRolesByCourseAndType(String courseId, RoleType roleType) {
    LinkedList<Tutor> matchingRoles = new LinkedList<>();
    for (Tutor tutor : tutors) {
        for (Course course : tutor.getCourses()) {
            if (tutor.getRoleType() == roleType && course.getCourseID().equals(courseId)) {
                matchingRoles.add(tutor);
                break;
            }
        }
    }
    return matchingRoles;
}
    
public void displayRolesByCourseAndType() {
    Scanner scanner = new Scanner(System.in);
    courseManagement.displayCourses();
    System.out.print("Enter Course ID: ");
    String courseId = scanner.nextLine().trim();
    
    // Updated prompt message to include descriptions of the role types
    printMenuHeader("Role Type");
    System.out.println("T - Tutor");
    System.out.println("PT - Practical Tutor");
    System.out.println("L - Lecturer");
    printMenuFooter();
    System.out.print("Your choice: ");
    String roleInput = scanner.nextLine().toUpperCase().trim();
    promptEnterToContinue(scanner);
    RoleType roleType = null;
    switch (roleInput) {
        case "T" -> roleType = RoleType.TUTOR;
        case "PT" -> roleType = RoleType.PRACTICAL_TUTOR;
        case "L" -> roleType = RoleType.LECTURER;
        default -> {
            System.out.println("Invalid role type. Please enter T, PT, or L.");
            promptEnterToContinue(scanner);
            return;
            }
    }
    
    LinkedList<Tutor> roles = findRolesByCourseAndType(courseId, roleType);
    if (roles.isEmpty()) {
        System.out.println("No " + roleType + " roles found for course ID: " + courseId);
        promptEnterToContinue(scanner);
    } else {
        for (Tutor role : roles) {
            System.out.println(role.getName() + " (" + role.getId() + ")");
        }
    }
    promptEnterToContinue(scanner);
}
public void listTutorsAndTutorialGroupsForCourse() {

    Scanner scanner = new Scanner(System.in);
            courseManagement.displayCourses();
    System.out.print("Enter Course ID: ");
    String courseId = scanner.nextLine().trim();

    Course course = findCourseById(courseId);
    if (course == null) {
        System.out.println("Course not found with ID: " + courseId);
        promptEnterToContinue(scanner);
        return;
    }

    printMenuHeader("Course Name: " + course.getCourseName());

    LinkedList<Tutor> courseTutors = course.getTutors();
    if (courseTutors.isEmpty()) {
        System.out.println("No tutors found for this course.");
        promptEnterToContinue(scanner);
    } else {
        System.out.println("Tutors for this course:");
        for (Tutor tutor : courseTutors) {
            System.out.println(tutor.getName() + " (ID: " + tutor.getId() + ")");
        }
    promptEnterToContinue(scanner);
    }

    LinkedList<TutorialGroup> courseGroups = course.getTutorialGroups();
    if (courseGroups.isEmpty()) {
        System.out.println("No tutorial groups found for this course.");
        promptEnterToContinue(scanner);
    } else {
        printMenuFooter();
        System.out.println("Tutorial Groups for this course:");
        for (TutorialGroup group : courseGroups) {
            if (group != null) {
                System.out.println("Group ID: " + group.getGroupId());
                promptEnterToContinue(scanner);
            } else {
                System.out.println("No tutorial groups found for this course.");
            }
        }
    }
}
public void listCoursesForEachTutor() {

    int idWidth = 8;
    int nameWidth = 20;
    int courseNameWidth = 35;
    int courseIdWidth = 10;

    String headerFormat = "| %-"+idWidth+"s | %-"+nameWidth+"s | %-"+courseNameWidth+"s | %-"+courseIdWidth+"s |%n";
    String detailFormat = "| %" + idWidth + "s | %" + nameWidth + "s | %-"+courseNameWidth+"s | %-"+courseIdWidth+"s |%n";

    System.out.printf(headerFormat, "Tutor ID", "Tutor Name", "Course Name", "Course ID");
    System.out.println(new String(new char[idWidth + nameWidth + courseNameWidth + courseIdWidth + 12]).replace('\0', '-'));
    for (Tutor tutor : tutors) {
        LinkedList<Course> courses = tutor.getCourses();
        if (courses == null || courses.isEmpty()) {
            System.out.printf(headerFormat, tutor.getId(), tutor.getName(), "No courses assigned", "");
        } else {
            boolean firstCoursePrinted = false;
            for (Course course : courses) {
                if (!firstCoursePrinted) {
                    System.out.printf(headerFormat, tutor.getId(), tutor.getName(), course.getCourseName(), course.getCourseID());
                    firstCoursePrinted = true;
                } else {
                    System.out.printf(detailFormat, "", "", course.getCourseName(), course.getCourseID());
                }
            }
        }
        System.out.println(new String(new char[idWidth + nameWidth + courseNameWidth + courseIdWidth + 12]).replace('\0', '-'));
    }
    promptEnterToContinue(scanner);
}
    public void filterTutorsByUserInput() {
        printMenuHeader("Please select a role type to filter by");
        System.out.println("1. Tutor");
        System.out.println("2. Practical Tutor");
        System.out.println("3. Lecturer");
        printMenuFooter();

        System.out.print("Enter your choice (1-3): ");
        int choice = scanner.nextInt();
        scanner.nextLine(); 
        promptEnterToContinue(scanner);

        // Convert the user input into a RoleType
        RoleType selectedRoleType = null;
        switch (choice) {
            case 1:
                selectedRoleType = RoleType.TUTOR;
                break;
            case 2:
                selectedRoleType = RoleType.PRACTICAL_TUTOR;
                break;
            case 3:
                selectedRoleType = RoleType.LECTURER;
                break;
            default:
                System.out.println("Invalid choice. Please select a number between 1 and 3.");
                promptEnterToContinue(scanner);
                return;
        }

        LinkedList<Tutor> filteredTutors = filterTutors(selectedRoleType, null);
        displayFilteredTutors(filteredTutors);
    }

    private boolean courseListContains(LinkedList<Course> courseList, String courseId) {
        for (Course course : courseList) {
            if (course.getCourseID().equals(courseId)) {
                return true;
            }
        }
        return false;
    }

    private LinkedList<Tutor> filterTutors(RoleType roleType, String courseId) {
        LinkedList<Tutor> filteredTutors = new LinkedList<>();
        for (Tutor tutor : tutors) {
            boolean roleMatches = (roleType == null || tutor.getRoleType().equals(roleType));
            boolean courseMatches = (courseId == null || courseListContains(tutor.getCourses(), courseId));
        
            if (roleMatches && courseMatches) {
                filteredTutors.add(tutor);
            }
        }
        return filteredTutors;
    }

    private void displayFilteredTutors(LinkedList<Tutor> filteredTutors) {
        if (filteredTutors.isEmpty()) {
            System.out.println("No tutors found for the selected role type.");
            promptEnterToContinue(scanner);
        } else {
            printMenuHeader("Filtered tutors");
            for (Tutor tutor : filteredTutors) {
                System.out.println(tutor.getName() + " (ID: " + tutor.getId() + ")");
            }
        }
    promptEnterToContinue(scanner);
    }  
        public void generateSummaryReport() {
        printMenuHeader("Select the type of summary report you want:");
        System.out.println("1. Tutor Summary Report");
        System.out.println("2. Tutorial Group Summary Report");
        printMenuFooter();
        System.out.print("Enter your choice (1 or 2): ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.println("Tutor Summary Report");
                generateTutorReport();
                break;
            case 2:
                System.out.println("Tutor Assignemnt Summary Report");
                generateTutorialGroupReport();
                break;
            default:
                System.out.println("Invalid choice. Please enter 1 or 2.");
                break;
        }
    }

public void generateTutorReport() {
    LinkedList<RoleType> roleTypes = new LinkedList<>();
    LinkedList<Integer> roleCounts = new LinkedList<>();

    // Populate roleTypes and roleCounts
    for (TutorialGroup group : tutorialGroups) {
        for (Tutor tutor : group.getTutors()) {
            RoleType tutorRole = tutor.getRoleType();
            // Manually search for the role in the roleTypes list
            boolean found = false;
            for (int i = 1; i <= roleTypes.getNumberOfEntries(); i++) {
                if (roleTypes.getEntry(i).equals(tutorRole)) {
                    int currentCount = roleCounts.getEntry(i);
                    roleCounts.replace(i, currentCount + 1);
                    found = true;
                    break;
                }
            }
            if (!found) { // RoleType not found, add new role type
                roleTypes.add(tutorRole);
                roleCounts.add(1);
            }
        }
    }
    System.out.println("==================================================================================");
    System.out.println("            TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
    System.out.println("                        TEACHING ASSIGNMENT MANAGEMENT SUBSYSTEM");
    System.out.println("                            TUTOR SUMMARY REPORT");
    System.out.println("                   ----------------------------------------");
    System.out.println("Generated at: " + new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a").format(new Date()));
    System.out.println(String.format("%-15s %-50s %-15s", "TUTOR ID", "TUTOR NAME", "ROLE TYPE"));
    System.out.println("----------------------------------------------------------------------------------");
    
    for (TutorialGroup group : tutorialGroups) {
        for (Tutor tutor : group.getTutors()) {
                System.out.println(String.format("%-15s %-50s %-15s", tutor.getId(), tutor.getName(), tutor.getRoleType()));
            }
    }
    System.out.println("----------------------------------------------------------------------------------");
    for (int i = 0; i < roleTypes.getNumberOfEntries(); i++) {
        RoleType currentRoleType = roleTypes.getEntry(i + 1);
        System.out.println(currentRoleType + ": " + roleCounts.getEntry(i + 1) + " tutors");
    } 
    System.out.println("==================================================================================");
    System.out.println("                     END OF THE TUTOR SUMMARY REPORT");
    promptEnterToContinue(scanner);
}


private void generateTutorialGroupReport() {
    System.out.println("==================================================================================");
    System.out.println("            TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY");
    System.out.println("                        TEACHING ASSIGNMENT MANAGEMNT SUBSYSTEM");
    System.out.println("                            TUTORIAL GROUP SUMMARY REPORT");
    System.out.println("                   ----------------------------------------");
    System.out.println("Generated at: " + new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a").format(new Date()));
    System.out.println(String.format("%-15s %-50s %-15s", "GROUP ID", "TUTOR NAME", "TUTOR ID"));
    System.out.println("----------      -----------------------------------------------    ---------------");
    
    for (TutorialGroup group : tutorialGroups) {
    boolean firstTutor = true;
    for (Tutor tutor : group.getTutors()) {  // Assuming getTutors() returns a LinkedList<Tutor>
        if (firstTutor) {
            System.out.println(String.format("%-15s %-50s %-15s", group.getGroupId(), tutor.getName(), tutor.getId()));
            firstTutor = false;
        } else {
            System.out.println(String.format("%-15s %-50s %-15s", "", tutor.getName(), tutor.getId()));
        }
    }
    if (firstTutor) { // if no tutors in this group
        System.out.println(String.format("%-15s %-50s %-15s", group.getGroupId(), "No tutors assigned", ""));
    }
    System.out.println("----------------------------------------------------------------------------------");
}
    TutorialGroup groupWithMostTutors = null;
    TutorialGroup groupWithLeastTutors = null;
    int mostTutorsCount = 0;
    int leastTutorsCount = Integer.MAX_VALUE;

    for (TutorialGroup group : tutorialGroups) {
        int tutorCount = 0;
        
        for (Tutor tutor : group.getTutors()) {
            tutorCount++;
        }
        
        if (tutorCount > mostTutorsCount) {
            mostTutorsCount = tutorCount;
            groupWithMostTutors = group;
        }
        
        if (tutorCount < leastTutorsCount) {
            leastTutorsCount = tutorCount;
            groupWithLeastTutors = group;
        }
    }

    if (groupWithMostTutors != null) {
        System.out.println("Tutorial Group with the most tutors: " + groupWithMostTutors.getGroupId() + " - " + mostTutorsCount + " tutors");
    } else {
        System.out.println("No group has tutors.");
    }

    if (groupWithLeastTutors != null && leastTutorsCount != Integer.MAX_VALUE) {
        System.out.println("Tutorial Group with the least tutors: " + groupWithLeastTutors.getGroupId() + " - " + leastTutorsCount + " tutors");
    } else {
        System.out.println("Every group has tutors.");
    }
        System.out.println("==================================================================================");
        System.out.println("                     END OF THE TUTORIAL GROUP SUMMARY REPORT");
        promptEnterToContinue(scanner);
    }
}

