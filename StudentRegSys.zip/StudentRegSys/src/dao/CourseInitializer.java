package dao;
import adt.*;
import entity.*;

public class CourseInitializer {
    private HashMap<String, Course> courses;
    private LinkedList<Course> courseList;
     
    public CourseInitializer() {
        this.courses = new HashMap<>();
        this.courseList = new LinkedList<>();
        initializeCourses();
    }
    
    private void initializeCourses(){
        TutorialGroupInitializer groupInitializer = new TutorialGroupInitializer();

        courses.put("BACS6683", new Course("BACS6683", "Introduction to Networking", 777.0, 16, Course.courseType.MAIN));
        courses.put("BAMS1044", new Course("BAMS1044", "Software Engineering", 700.0, 14, Course.courseType.MAIN));
        courses.put("BAIT1102", new Course("BAIT1102", "Web Development", 650.0, 16, Course.courseType.MAIN));
        courses.put("AACS1543", new Course("AACS1543", "Introduction to Entrepreneurship", 600.0, 15, Course.courseType.ELECTIVE));
   
        // Adding courses directly to LinkedList with Tutorial Groups
        Course networkingCourse = new Course("BACS6683", "Introduction to Networking", 777.0, 16, Course.courseType.MAIN);
        networkingCourse.addTutorialGroup(groupInitializer.getTutorialGroups().getEntry(1));
        courseList.add(networkingCourse);
        
        Course softwareEngineeringCourse = new Course("BAMS1044", "Software Engineering", 700.0, 14, Course.courseType.MAIN);
        softwareEngineeringCourse.addTutorialGroup(groupInitializer.getTutorialGroups().getEntry(2));
        courseList.add(softwareEngineeringCourse);
        
        Course webDevelopmentCourse = new Course("BAIT1102", "Web Development", 650.0, 16, Course.courseType.MAIN);
        webDevelopmentCourse.addTutorialGroup(groupInitializer.getTutorialGroups().getEntry(3));
        webDevelopmentCourse.addTutorialGroup(groupInitializer.getTutorialGroups().getEntry(4));        
        courseList.add(webDevelopmentCourse);

        Course entrepreneurshipCourse = new Course("AACS1543", "Introduction to Entrepreneurship", 600.0, 15, Course.courseType.ELECTIVE);
        entrepreneurshipCourse.addTutorialGroup(groupInitializer.getTutorialGroups().getEntry(5));
        courseList.add(entrepreneurshipCourse);
    }
  
    public HashMap<String, Course> getCourses() {
        return courses;
    }
    
    public LinkedList<Course> getCourseList() {
        return courseList;
    }
        
    public Course getCourseById(String courseID) {
        return courses.get(courseID);
    }
    
    public HashMap<String, Course> initialize() {
        initializeCourses();
        return getCourses();
    }
}