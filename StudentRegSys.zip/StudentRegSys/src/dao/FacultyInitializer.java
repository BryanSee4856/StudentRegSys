package dao;
import adt.*;
import entity.*;

public class FacultyInitializer {
    private static FacultyInitializer instance; // Singleton instance
    private HashMap<String, Faculty> faculties;
    private CourseInitializer courseInitializer;
    private HashMap<String, String> programmeToFacultyMap; // Map programme IDs to faculty IDs
    
    public FacultyInitializer(CourseInitializer courseInitializer) {
        this.faculties = new HashMap<>();
        this.courseInitializer = new CourseInitializer();
        this.programmeToFacultyMap = new HashMap<>();
        setupProgrammeFacultyMapping();
        initializeFaculties();
    }
    
    // Public method to get singleton instance
    public static /*synchronized*/ FacultyInitializer getInstance(CourseInitializer courseInitializer) {
        if (instance == null) {
            instance = new FacultyInitializer(courseInitializer);
        }
        return instance;
    }
    
    private void setupProgrammeFacultyMapping() {
        programmeToFacultyMap.put("DCS", "FAFB");
        programmeToFacultyMap.put("RSW", "FOCS");
        programmeToFacultyMap.put("RIS", "FOCS");
        programmeToFacultyMap.put("RDS", "FOCS");
    }
    
    private void initializeFaculties() {
        // Initialize faculties here
        Faculty f1 = new Faculty("FOCS", "Faculty of Computing and Information Technology");
        Faculty f2 = new Faculty("FAFB", "Faculty of Accountancy Finance and Business");
        
        // Add faculties to the HashMap
        faculties.put(f1.getFacultyID(), f1);
        faculties.put(f2.getFacultyID(), f2);
        
        // Associate courses with faculties
        coursesWithFaculty(f1, "BACS6683"); 
        coursesWithFaculty(f1, "BAMS1044");
        coursesWithFaculty(f1, "BAIT1102");
        coursesWithFaculty(f2, "AACS1543");

        for (Course course : courseInitializer.getCourses().values()) {
            for (Programme programme : course.getProgrammes().values()) {
                String facultyId = programmeToFacultyMap.get(programme.getProgrammeID());
                faculties.get(facultyId).getCourses().put(course.getCourseID(), course);
            }
        }
    }
    
    private void coursesWithFaculty(Faculty faculty, String courseID) {
        Course course = courseInitializer.getCourseById(courseID);
        if (faculty != null && course != null) {
            faculty.getCourses().put(course.getCourseID(), course);
        }
    }

    public void associateCourseWithFaculty(String programmeId, Course course) {
        String facultyId = programmeToFacultyMap.get(programmeId);
        if (facultyId != null && course != null) {
            faculties.get(facultyId).getCourses().put(course.getCourseID(), course);
        }
    }
    
    public HashMap<String, Faculty> getFaculties() {
        return faculties;
    }
}
