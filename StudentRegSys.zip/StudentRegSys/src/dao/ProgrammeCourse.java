package dao;
import adt.*;
import entity.*;

public class ProgrammeCourse {
    private HashMap<String, Course> courses;
    private HashMap<String, Programme> programmes;
    private CourseInitializer courseInitializer;
    private ProgrammeInitializer programmeInitializer;
    
    public ProgrammeCourse(){
        courseInitializer = new CourseInitializer();
        programmeInitializer = new ProgrammeInitializer();
        courses = courseInitializer.getCourses();
        programmes = programmeInitializer.getProgrammes();
        associateCoursesWithProgrammes();
    }
    
    private void associateCoursesWithProgrammes() {
        // associate courses with programmes
        associate("DCS", "BAIT1102");
        associate("RIS", "BACS6683");
        associate("RSW", "BAMS1044");
        associate("RDS", "AACS1543");
    }
    
    private void associate(String programmeId, String courseId) {
    Programme programme = programmes.get(programmeId);
    Course course = courses.get(courseId);
    if (programme != null && course != null) {
        programme.getCourses().put(courseId, course);
        course.getProgrammes().put(programmeId, programme);
        }
    }
    
    public HashMap<String, Course> getCourses() {
        return courses;
    }

    public HashMap<String, Programme> getProgrammes() {
        return programmes;
    }
    
    public Programme getProgrammeById(String programmeID) {
        return programmes.get(programmeID);
    }
    
    // Ensure this method exists in ProgrammeInitializer
    public boolean isValidProgramme(String programmeID) {
        return programmes.containsKey(programmeID);
    }  
        
    public Course getCourseById(String courseID) {
        return courses.get(courseID);
    }
}
