package dao;
import adt.*;
import entity.*;

public class ProgrammeInitializer {
    private HashMap<String, Programme> programmes;

    public ProgrammeInitializer() {
        this.programmes = new HashMap<>();
        initializeProgrammes();
    }
    
    private void initializeProgrammes() {
        // Initialize programmes here
        programmes.put("DCS", new Programme("DCS", "Database Accounting"));
        programmes.put("RSW", new Programme("RSW", "Software Engineering"));
        programmes.put("RIS", new Programme("RIS", "Information Security"));
        programmes.put("RDS", new Programme("RDS", "Data Science"));  
    }
    
    public HashMap<String, Programme> getProgrammes() {
        return programmes;
    }
    
    public Programme getProgrammeById(String programmeID) {
        return programmes.get(programmeID);
    }
    
    // Ensure this method exists in ProgrammeInitializer
    public boolean isValidProgramme(String programmeID) {
        return programmes.containsKey(programmeID.toUpperCase()); // Assume programmes keys are stored in upper case
    }

    public HashMap<String, Programme> initialize() {
        initializeProgrammes();
        return getProgrammes();
    }
    
    public String getProgrammeNameById(String programmeID) {
        Programme programme = getProgrammeById(programmeID);
        return (programme != null) ? programme.getProgrammeName() : "Unknown Programme";
    }
}