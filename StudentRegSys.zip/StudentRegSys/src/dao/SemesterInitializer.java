package dao;
import adt.*;
import entity.*;

public class SemesterInitializer {
    private HashMap<String, Semester> semesters;
    private ProgrammeCourse programmeCourse; // Using centralized class for course and programme data
    private String currentSemesterId = "Year1S1";

    public SemesterInitializer(ProgrammeCourse programmeCourse) {
        this.semesters = new HashMap<>();
        this.programmeCourse = programmeCourse;
        initializeSemester();
    }

    private void initializeSemester() {
        Semester semester = new Semester("Year1S1", "Spring 2024");

        // Retrieve courses from ProgrammeCourse and add to the semester
        addCourseToSemester(semester, "BACS6683");
        addCourseToSemester(semester, "BAMS1044");
        addCourseToSemester(semester, "BAIT1102");
        addCourseToSemester(semester, "AACS1543");

        // Store the semester
        semesters.put(semester.getSemesterID(), semester);
    }

    private void addCourseToSemester(Semester semester, String courseID) {
        Course course = programmeCourse.getCourseById(courseID);
        if (course != null) {
            semester.getCoursesOffered().put(course.getCourseID(), course);
        }
    }

    public HashMap<String, Semester> getSemesters() {
        return semesters;
    }

    public Semester getSemesterById(String semesterID) {
        return semesters.get(semesterID);
    }
    
    public void addCourseToCurrentSemester(String courseId) {
        Semester semester = getSemesterById(currentSemesterId);
        if (semester != null) {
            Course course = programmeCourse.getCourseById(courseId);
            if (course != null && !semester.getCoursesOffered().containsKey(courseId)) {
                semester.getCoursesOffered().put(courseId, course);
            }
        }
    }
}
