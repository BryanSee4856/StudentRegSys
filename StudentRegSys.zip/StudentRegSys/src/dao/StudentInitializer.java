package dao;

import adt.ArrayList;
import adt.ListInterface;
import entity.Student;

/**
 * Initializes a list of students with predefined data.
 */
public class StudentInitializer {
    private ListInterface<Student> students;

    /**
     * Constructs a new StudentInitializer and initializes the student list.
     */
    public StudentInitializer() {
        this.students = new ArrayList<>();
        initializeStudents(); // Automatically populates the list upon creation.
    }

    /**
     * Populates the student list with predefined data.
     */
    private void initializeStudents() {
        students.add(new Student("22RSW13530", "Alice Johnson", "850101-14-5567", "alice.johnson@email.com", "RSW"));
        students.add(new Student("22RSW13531", "Bob Smith", "850102-14-5568", "bob.smith@email.com", "RSW"));
        // Additional students can be added here if needed.
    }

    /**
     * Returns the list of initialized students.
     * @return a ListInterface containing the predefined students.
     */
    public ListInterface<Student> getStudents() {
        return students;
    }

    /**
     * Checks if an Identification Code (IC) already exists in the student list.
     * @param ic The IC to check.
     * @return true if the IC exists, false otherwise.
     */
    public boolean isIcExists(String ic) {
        for (Student student : students) {
            if (student.getIc().equals(ic)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isIdExists(String id) {
        for (Student student : students) {
            if (student.getStudentId().equals(id)) {
                return true;
            }
        }
        return false;
    }
}
