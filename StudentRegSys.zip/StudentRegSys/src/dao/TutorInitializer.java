package dao;

import adt.LinkedList;
import entity.Course;
import entity.RoleType;
import entity.Tutor;

public class TutorInitializer {
    private LinkedList<Tutor> tutors;

    // Assuming CourseInitializer can be accessed statically or passed as an argument
    private LinkedList<Course> courseList;

    public TutorInitializer(LinkedList<Course> courseList) {
        this.courseList = courseList;
        this.tutors = new LinkedList<>();
        initializeTutors();
    }

    private void initializeTutors() {
        // Utilize the passed LinkedList to find courses
        Course c1 = findCourse("BACS6683");
        Course c2 = findCourse("BAMS1044");
        Course c3 = findCourse("BAIT1102");
        Course c4 = findCourse("AACS1543");
    
        // Assign course lists to tutors and add tutors to the tutors list
        createAndAddTutor("John Doe", "T001", RoleType.TUTOR, c1, c2);
        createAndAddTutor("Jane Smith", "T002", RoleType.PRACTICAL_TUTOR, c2, c3);
        createAndAddTutor("Emily Johnson", "T003", RoleType.LECTURER, c1, c3, c4);
        createAndAddTutor("Michael Brown", "T004", RoleType.TUTOR, c1);
        createAndAddTutor("Jessica Garcia", "T005",RoleType.PRACTICAL_TUTOR,c1);
        createAndAddTutor("William Davis", "T006",RoleType.LECTURER,c1,c2);
        createAndAddTutor("Linda Wilson", "T007",RoleType.TUTOR,c4);
        createAndAddTutor("Robert Miller", "T008",RoleType.PRACTICAL_TUTOR,c3,c4);
        createAndAddTutor("Sarah Moore", "T009",RoleType.LECTURER,c3,c4);
        createAndAddTutor("James Taylor", "T010",RoleType.TUTOR,c2,c3);
        createAndAddTutor("Taylor Swift", "T011",RoleType.PRACTICAL_TUTOR,c1,c2,c3);
    }

    private Course findCourse(String courseId) {
        for (Course course : courseList) {
            if (course.getCourseID().equals(courseId)) {
                return course;
            }
        }
        return null; // Or handle the case where the course is not found
    }

    private void createAndAddTutor(String name, String id, RoleType roleType, Course... courses) {
        Tutor tutor = new Tutor(name, id, roleType);
        for (Course course : courses) {
            if (course != null) { // Check if course is not null
                tutor.getCourses().add(course); // Add each course to the tutor's course list
                course.addTutor(tutor); // Optionally, if a course should keep track of its tutors
            }
        }
        tutors.add(tutor);
    }

    public LinkedList<Tutor> getTutors() {
        return tutors;
    }
}
