/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.Tutor;
import entity.TutorialGroup;
import adt.LinkedList;
import entity.RoleType;

public class TutorialGroupInitializer {
    private LinkedList<TutorialGroup> tutorialGroups;

    public TutorialGroupInitializer() {
        tutorialGroups = new LinkedList<>();
        initializeGroups();
    }

    private void initializeGroups() {
        // Create Tutors
        Tutor tutor1 = new Tutor("John Doe", "T001",RoleType.TUTOR);
        Tutor tutor2 = new Tutor("Jane Smith", "T002",RoleType.PRACTICAL_TUTOR);
        Tutor tutor3 = new Tutor("Emily Johnson", "T003",RoleType.LECTURER);
        Tutor tutor4 = new Tutor("Michael Brown", "T004",RoleType.TUTOR);
        Tutor tutor5 = new Tutor("Jessica Garcia", "T005",RoleType.PRACTICAL_TUTOR);
        Tutor tutor6 = new Tutor("William Davis", "T006",RoleType.LECTURER);
        Tutor tutor7 = new Tutor("Linda Wilson", "T007",RoleType.TUTOR);
        Tutor tutor8 = new Tutor("Robert Miller", "T008",RoleType.PRACTICAL_TUTOR);
        Tutor tutor9 = new Tutor("Sarah Moore", "T009",RoleType.LECTURER);
        Tutor tutor10 = new Tutor("James Taylor", "T010",RoleType.TUTOR);
        Tutor tutor11 = new Tutor("Taylor Swift", "T011",RoleType.PRACTICAL_TUTOR);

        // Create Tutorial Groups and assign Tutors
        TutorialGroup group1 = new TutorialGroup("TG01");
        group1.addTutor(tutor1);
        group1.addTutor(tutor2);

        TutorialGroup group2 = new TutorialGroup("TG02");
        group2.addTutor(tutor3);
        group2.addTutor(tutor4);

        TutorialGroup group3 = new TutorialGroup("TG03");
        group3.addTutor(tutor5);
        group3.addTutor(tutor6);

        TutorialGroup group4 = new TutorialGroup("TG04");
        group4.addTutor(tutor7);
        group4.addTutor(tutor8);
        group4.addTutor(tutor9);

        TutorialGroup group5 = new TutorialGroup("TG05");


        // Add Tutorial Groups to the list
        tutorialGroups.add(group1);
        tutorialGroups.add(group2);
        tutorialGroups.add(group3);
        tutorialGroups.add(group4);
        tutorialGroups.add(group5);
    }

    public LinkedList<TutorialGroup> getTutorialGroups() {
        return tutorialGroups;
    }
}

