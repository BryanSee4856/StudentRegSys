package entity;

public class Enrollment {
    private Course course;
    private String registrationType; // Options: "Resit", "Repeat", "First"

    /**
     * Constructs an Enrollment with specified details.
     * @param course The course to which the enrollment pertains.
     * @param registrationType The type of registration ("Resit", "Repeat", "First").
     */
    public Enrollment(Course course, String registrationType) {
        this.course = course;
        this.registrationType = registrationType;
    }

    /**
     * Returns the course associated with this enrollment.
     * @return The course of this enrollment.
     */
    public Course getCourse() {
        return course;
    }

    /**
     * Sets the course for this enrollment.
     * @param course The course to be set for this enrollment.
     */
    public void setCourse(Course course) {
        this.course = course;
    }

    /**
     * Returns the type of registration for this enrollment.
     * @return The registration type ("Resit", "Repeat", "First").
     */
    public String getRegistrationType() {
        return registrationType;
    }

    /**
     * Sets the registration type for this enrollment.
     * @param registrationType The type of registration ("Resit", "Repeat", "First").
     */
    public void setRegistrationType(String registrationType) {
        this.registrationType = registrationType;
    }
}
