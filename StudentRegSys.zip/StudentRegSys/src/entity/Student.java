package entity;

import adt.ArrayList;
import adt.ListInterface;

/**
 * Represents a student with a unique ID, name, identification number, chosen email, and programmed.
 * This class is designed to simplify student identity creation.
 */
public class Student implements Comparable<Student> {
    private String studentId;
    private String name;
    private String ic;
    private String email;
    private String programme;
    private ListInterface<Enrollment> enrollments; // List to store enrollments

    /**
     * Constructs a Student with default values.
     */
    public Student() {
        this.studentId = "defaultID"; 
        this.name = "defaultName";
        this.ic = "defaultIC";
        this.email = "default@example.com";
        this.programme = "defaultProgramme";
    }

    /**
     * Constructs a Student with specified details.
     * @param studentId Unique identifier for the student.
     * @param name Student's name.
     * @param ic Student's IC number.
     * @param email Student's email.
     * @param programme Student's programmed.
     */
    public Student(String studentId, String name, String ic, String email, String programme) {
        this.studentId = studentId;
        this.name = name;
        this.ic = ic;
        this.email = email;
        this.programme = programme;
        this.enrollments = new ArrayList<>(); // Initialize the list of enrollments
    }

    // Getters
    public String getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getIc() { return ic; }
    public String getEmail() { return email; }
    public String getProgramme() { return programme; }
    public ListInterface<Enrollment> getEnrollments() { return enrollments; }

    public void addEnrollment(Enrollment enrollment) {
        this.enrollments.add(enrollment);
    }
    
    // Simple Setters
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setIc(String ic) {
        this.ic = ic;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setProgramme(String programme) {
        this.programme = programme;
    }

    @Override
    public int compareTo(Student other) {
        return this.studentId.compareTo(other.studentId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return studentId.equals(student.studentId);
    }

    @Override
    public int hashCode() {
        return studentId.hashCode();
    }

    @Override
    public String toString() {
        // Set widths for each field to ensure alignment
        int idWidth = 10;    // Width for studentId
        int nameWidth = 20;  // Width for name
        int icWidth = 15;    // Width for IC
        int emailWidth = 30; // Width for email
        int progWidth = 15;  // Width for programme

        return String.format("| %-" + idWidth + "s | %-" + nameWidth + "s | %-" + icWidth + "s | %-" + emailWidth + "s | %-" + progWidth + "s |",
                studentId, name, ic, email, programme);
    }

}
