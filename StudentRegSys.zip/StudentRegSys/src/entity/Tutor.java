/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import adt.LinkedList;

public class Tutor{
    
    private String name;
    private String id;
    private LinkedList<Course> courses;  
    private RoleType roleType;

    public Tutor(String name, String id, RoleType roleType) {
        this.courses = new LinkedList<>();
        this.name = name;
        this.id = id;
        this.roleType = roleType;
        this.courses = new LinkedList<>();
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public adt.LinkedList<Course> getCourses() {
        return courses;
    }

    public RoleType getRoleType() {
        return roleType;
    }
    
    public void setCourses(LinkedList<Course> courses) {
        this.courses = courses;
    }

    public String getTutorId() {
        return id;
    }
}


