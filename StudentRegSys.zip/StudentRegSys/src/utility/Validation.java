package utility;

import dao.StudentInitializer;
import dao.ProgrammeInitializer;
import java.util.Scanner;

public class Validation {
    public static String promptForInput(Scanner scanner, String message, String regex) {
        String input;
        do {
            System.out.print(message); // Use print instead of println
            input = scanner.nextLine().trim();
            if (!input.matches(regex)) {
                System.out.println("Invalid format. Please try again.");
            }
        } while (!input.matches(regex));
        return input;
    }

    public static String promptForUniqueInput(Scanner scanner, String message, String regex, String errorMessage, StudentInitializer initializer, String type) {
        String input;
        boolean exists;
        do {
            System.out.print(message); // Use print instead of println
            input = promptForInput(scanner, "", regex);
            exists = (type.equals("IC")) ? initializer.isIcExists(input) : initializer.isIdExists(input);
            if (exists) {
                System.out.println(type + " already exists. Please enter a different " + type + ".");
            }
        } while (exists);
        return input;
    }

    public static String promptForValidProgram(Scanner scanner, ProgrammeInitializer programmeInitializer) {
        String programme;
        do {
            System.out.print("Enter Student Programme: ");
            programme = scanner.nextLine().trim().toUpperCase(); // Convert input to upper case
            if (!programmeInitializer.isValidProgramme(programme)) {
                System.out.println("Invalid programme ID. Please try again.");
            }
        } while (!programmeInitializer.isValidProgramme(programme));
        return programme;
    }

    
    public static String promptForRegistrationType(Scanner scanner) {
        System.out.println("Choose the registration type:");
        System.out.println("1. First");
        System.out.println("2. Resit");
        System.out.println("3. Repeat");
        String registrationType = "";
        boolean valid = false;
        while (!valid) {
            System.out.print("Enter your choice (1, 2, 3): ");
            String input = scanner.nextLine().trim();
            switch (input) {
                case "1":
                    registrationType = "First";
                    valid = true;
                    break;
                case "2":
                    registrationType = "Resit";
                    valid = true;
                    break;
                case "3":
                    registrationType = "Repeat";
                    valid = true;
                    break;
                default:
                    System.out.println("Invalid input. Please enter a number between 1 and 3.");
            }
        }
        return registrationType;
    }
    
    public static String promptForCourseType(Scanner scanner) {
        System.out.println("Select the course type to filter:");
        System.out.println("1 - MAIN");
        System.out.println("2 - ELECTIVE");
        System.out.print("Enter your choice (1 or 2): ");
        int choice = Integer.parseInt(promptForInput(scanner, "", "\\d+"));
        switch (choice) {
            case 1:
                return "MAIN";
            case 2:
                return "ELECTIVE";
            default:
                System.out.println("Invalid choice. Please enter 1 or 2.");
                return promptForCourseType(scanner); // Recursion to handle invalid input
        }
    }
}
